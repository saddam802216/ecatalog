<?php

    require_once('../include/include.php');
    $isLogin = Helper::getLoginUser();
    
    
    if(!$isLogin) {
        if(isset($_GET['page']) && $_GET['page']=='registration') {
            include ("pages/registration.php");
            exit;
        }
        include ("pages/login.php");
        exit;
    }
    if(isset($_GET['page']) && !empty($_GET['page'])) {
        build_page($_GET['page']);
    }else {
        build_page();
    }

    function build_page($thispage='index'){
        include '../'.DIR_INCLUDE_PATH."header.php";
        
        if($thispage=='index' && file_exists("../".DIR_INCLUDE_PATH."pages/".$thispage.".php")) {
            include ("../".DIR_INCLUDE_PATH."pages/".$thispage.".php");
        }elseif (file_exists("pages/".$thispage.".php")) { 
            include ("pages/".$thispage.".php");
        }else { 
            echo "<div style=\"margin:10px;\">";
            echo "You are not authorized to view this page!<br />";
            echo "</div>";
        }
        
        include '../'.DIR_INCLUDE_PATH."footer.php";
    }


?>