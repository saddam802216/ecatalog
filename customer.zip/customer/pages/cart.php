<?php

$cartItems = Helper::getCartItems();

?>

<style>

.hideMe{
    display: none;
}
.float-left {
    float: left;
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center">
                                    <h4 class="page-title">&nbsp;</h4>
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">
                                                
                                                <li class="float-left"><p class="page-title"> <strong>Cart</strong></p></li>

                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'customer/index.php'?>">Home</a></li>
                                                
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'customer/index.php?page=products'?>">Cart</a></li>

                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->

                        <!-- Order Table Start -->


                        <div class="row">
                        <form class="col-sm-12" name="cart_form" method="POST" id="cart_form" action="../include/store.php" enctype="multipart/form-data">
                            <?php //prx($cartItems);  ?>
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Image</th>
                                                <th scope="col">Product</th>
                                                <th scope="col" class="text-center">Quantity</th>
                                                <th scope="col" class="text-right">Unit Price</th>
                                                <th scope="col" class="text-right">Price</th>
                                                <th> </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                            $userid = Helper::getUserId();
                                            $user = Helper::getCustomerById($userid);
                                            $subTotal = 0.0000;
                                            $shipping = 0.0000;
                                            foreach($cartItems as $item) {
                                                $product = $item->product;
                                                $cover_photo = null;
                                                $custPrice = 0.0000;
                                                $cover_image = BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png';
                                                
                                                if(isset($product->images) && !empty($product->images)) {
                                                    foreach($product->images as $image) {
                                                        if($image->file_cover == 1) {
                                                            $cover_image = BASE_URL.UPLOAD_IMAGE_PATH.$image->file_name;
                                                        }
                                                    }
                                                }    
                                                // prx($user);
                                                if(isset($product->prices) && !empty($product->prices)) {
                                                    foreach($product->prices as $price) {
                                                        if($price->custgroup_id==$user->custgroup_id) {
                                                            $custPrice = $price->product_price;
                                                        }
                                                    }
                                                    if(empty($custPrice)) {
                                                        $default_group = Helper::defaultCustomerGroup();
                                                        if(isset($default_group->custgroup_id) && !empty($default_group->custgroup_id)) {
                                                            foreach($product->prices as $price) {
                                                                if($price->custgroup_id==$default_group->custgroup_id) {
                                                                    $custPrice = $price->product_price;
                                                                }
                                                            }
                                                        }
                                                    }
                                                } 
                                                
                                                $unitPrice = $custPrice;
                                                $price = $unitPrice*$item->quantity;
                                                $subTotal += $price;
                                            
                                                ?>
                                            <tr>
                                                <td><img src="<?=$cover_image?>" width="50px" height="50px" /> </td>
                                                <td><?=$product->product_name?></td>
                                                <td style="width:10%">
                                                    <input class="form-control onChangeQuantity" type="number" name="quantity[]" value="<?=$item->quantity?>"  />
                                                    <input class="form-control product-id" type="hidden" name="product_id[]" value="<?=$item->product_id?>"  />
                                                    <input class="form-control" type="hidden" name="product_name[]" value="<?=$product->product_name?>"  />
                                                    <input class="form-control" type="hidden" name="product_price[]" value="<?=$custPrice?>" />
                                                </td>
                                                <td class="text-right"><?=$custPrice?></td>
                                                <td class="text-right"><?=$custPrice*$item->quantity?></td>
                                                <td class="text-right">
                                                    <button class="btn btn-sm btn-danger removeCartItem" data-id="<?=$item->product_id?>" data-qty="<?=$item->quantity?>"><i class="fa fa-trash"></i></button> 
                                                </td>
                                                
                                            </tr>
                                                
                                                <?php } ?>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Sub-Total</td>
                                                <td class="text-right"><?=$subTotal?></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Shipping</td>
                                                <td class="text-right"><?=$shipping?></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><strong>Total</strong></td>
                                                <td class="text-right"><strong><?=$subTotal+$shipping?></strong></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col mb-2">
                                <div class="row">
                                    <div class="col-sm-12  col-md-6">
                                        <button class="btn btn-block btn-light">Continue Shopping</button>
                                    </div>
                                    <div class="col-sm-12 col-md-6 text-right">
                                        <input type="submit" name="submit_checkout" class="btn btn-lg btn-block btn-success text-uppercase" value="Checkout" />
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>



                        <!-- Order Table End -->
                        
                        
                </section>      
                </section>      
               
<script>

// Remove Cart Ajax

$(document).on('click', '.removeCartItem', function(e){
    e.preventDefault();
    if(!confirm("Do you want to remove this item!")) {
        return false;
    }
    let this_tr = $(this).closest('tr');
    let product_id = $(this).attr('data-id');
    
    $.ajax({
        type: 'post',
        url: '../include/ajax.php', 
        data: {'product_id':product_id, 'task':'removeCartItem'},
        dataType: 'json',
        beforeSend: function() {
            $('.loader').show();
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function (response) {
            if(response.success) {
                document.location.reload();
            }else {
                alert(response.message);
            }
            
        }
    });
}); 

// Update quantity Ajax

$(document).on('change', '.onChangeQuantity', function(e){
    e.preventDefault();
    if(!confirm("Do you want to change this item quantity")) {
        return false;
    }
    let quantity = $(this).val();
    let product_id = $(this).closest('td').find('.product-id').val(); 
    
    $.ajax({
        type: 'post',
        url: '../include/ajax.php', 
        data: {'product_id':product_id, 'quantity':quantity, 'task':'updateCartProductQuantity'},
        dataType: 'json',
        beforeSend: function() {
            $('.loader').show();
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function (response) {
            if(response.success) {
                document.location.reload();
            }else {
                alert(response.message);
            }
            
        }
    });
}); 
    
</script>