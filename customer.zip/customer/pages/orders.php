<?php

$orders = Helper::getCustomerOrders();

?>

<style>

.hideMe{
    display: none;
}
.order-main {
    margin: 20px;
    border: dashed 2px #4ecdc4;
    padding: 10px;
}
.float-left {
    float: left;
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center">
                                    <h4 class="page-title">&nbsp;</h4>
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">

                                            <li class="float-left"><p class="page-title"> <strong>Orders</strong></p></li>
                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'customer/index.php'?>">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'customer/index.php?page=orders'?>">Orders</a></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->

                        <!-- Order Table Start -->


                        <div class="row">
                            <?php 
                            
                            //prx($orders); 
                            foreach($orders as $order) {
                             
                            ?>
                            <div class="col-12 order-main">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <p> <?='Order No : '.$order->order_id?> </p><hr>
                                        <thead>
                                            <tr>
                                                <th scope="col">Image</th>
                                                <th scope="col">Product</th>
                                                <th scope="col"  class="text-right">Quantity</th>
                                                <th scope="col" class="text-right">Unit Price</th>
                                                <th scope="col" class="text-right">Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php
                                            $user = Helper::getUser();
                                            $subTotal = 0.0000;
                                            $shipping = 0.0000;
                                            foreach($order->items as $item) {
                                                $product = $item->product;
                                                $cover_photo = null;
                                                $custPrice = 0.0000;
                                                $cover_image = BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png';
                                                
                                                if(isset($product->images) && !empty($product->images)) {
                                                    foreach($product->images as $image) {
                                                        if($image->file_cover == 1) {
                                                            $cover_image = BASE_URL.UPLOAD_IMAGE_PATH.$image->file_name;
                                                        }
                                                    }
                                                }    
                                                // prx($user);
                                                if(isset($product->prices) && !empty($product->prices) && isset($user['user_type']) && $user['user_type']=='customer') {
                                                    foreach($product->prices as $price) {
                                                        if($price->custgroup_id==$user['custgroup_id']) {
                                                            $custPrice = $price->product_price;
                                                        }
                                                    }
                                                    if(empty($custPrice)) {
                                                        $default_group = Helper::defaultCustomerGroup();
                                                        if(isset($default_group->custgroup_id) && !empty($default_group->custgroup_id)) {
                                                            foreach($product->prices as $price) {
                                                                if($price->custgroup_id==$default_group->custgroup_id) {
                                                                    $custPrice = $price->product_price;
                                                                }
                                                            }
                                                        }
                                                    }
                                                } 
                                                
                                                $unitPrice = $item->item_price;
                                                $quantity = $item->item_quantity;
                                                $price = $unitPrice*$quantity;
                                                $subTotal += $price;
                                            
                                                ?>
                                            <tr>
                                                <td><img src="<?=$cover_image?>" width="50px" height="50px" /> </td>
                                                <td><?=$product->product_name?></td>
                                                <td class="text-right"><?=$quantity?></td>
                                                <td class="text-right"><?=$unitPrice?></td>
                                                <td class="text-right"><?=$price?></td>
                                            </tr>
                                                
                                                <?php } ?>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Sub-Total</td>
                                                <td class="text-right"><?=$subTotal?></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Shipping</td>
                                                <td class="text-right"><?=$shipping?></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><strong>Total</strong></td>
                                                <td class="text-right"><strong><?=$subTotal+$shipping?></strong></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <?php } ?>
                            
                        </div>



                        <!-- Order Table End -->
                        
                        
                </section>      
                </section>      
               
<script>

    
</script>