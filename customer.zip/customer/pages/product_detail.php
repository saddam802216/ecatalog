<?php
$id = 0;
if(isset($_GET['id']) && !empty($_GET['id'])) {
  $id = $_GET['id'];
}
$product = Helper::getProductDetail($id);
$total_quantity = Helper::getCartCount();
// prx($product);
?>

<style>
.float-right {
    float: right;
}
.product-top {
    padding: 20px 10px;
}
.cart-area {
    position: relative;
    padding-right: 27px;
}
.cart-count {
    position: absolute;
    top: -18px;
    background: red;
    color: #fff;
    padding: 3px 6px;
    border-radius: 50%;
}
/*****************globals*************/
img {
  max-width: 100%; }

.preview {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -webkit-flex-direction: column;
      -ms-flex-direction: column;
          flex-direction: column; }
  @media screen and (max-width: 996px) {
    .preview {
      margin-bottom: 20px; } }

.preview-pic {
  -webkit-box-flex: 1;
  -webkit-flex-grow: 1;
      -ms-flex-positive: 1;
          flex-grow: 1; }

.preview-thumbnail.nav-tabs {
  border: none;
  margin-top: 15px; }
  .preview-thumbnail.nav-tabs li {
    width: 18%;
    margin-right: 2.5%; }
    .preview-thumbnail.nav-tabs li img {
      max-width: 100%;
      display: block; }
    .preview-thumbnail.nav-tabs li a {
      padding: 0;
      margin: 0; }
    .preview-thumbnail.nav-tabs li:last-of-type {
      margin-right: 0; }

.tab-content {
  overflow: hidden; }
  .tab-content img {
    width: 100%;
    -webkit-animation-name: opacity;
            animation-name: opacity;
    -webkit-animation-duration: .3s;
            animation-duration: .3s; }

.card {
  margin-top: 0px;
  background: #eee;
  /*padding: 3em;*/
  line-height: 1.5em; }

@media screen and (min-width: 997px) {
  /* .wrapper {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex; }  */
    }

.details {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -webkit-flex-direction: column;
      -ms-flex-direction: column;
          flex-direction: column; }

.colors {
  -webkit-box-flex: 1;
  -webkit-flex-grow: 1;
      -ms-flex-positive: 1;
          flex-grow: 1; }

.product-title, .price, .sizes, .colors {
  text-transform: UPPERCASE;
  font-weight: bold; }

.checked, .price span {
  color: #ff9f1a; }

.product-title, .rating, .product-description, .price, .vote, .sizes {
  margin-bottom: 15px; }

.product-title {
  margin-top: 0; }

.size {
  margin-right: 10px; }
  .size:first-of-type {
    margin-left: 40px; }

.color {
  display: inline-block;
  vertical-align: middle;
  margin-right: 10px;
  height: 2em;
  width: 2em;
  border-radius: 2px; }
  .color:first-of-type {
    margin-left: 20px; }

.add-to-cart, .like {
  background: #ff9f1a;
  padding: 1.2em 1.5em;
  border: none;
  text-transform: UPPERCASE;
  font-weight: bold;
  color: #fff;
  -webkit-transition: background .3s ease;
          transition: background .3s ease; }
  .add-to-cart:hover, .like:hover {
    background: #b36800;
    color: #fff; }

.not-available {
  text-align: center;
  line-height: 2em; }
  .not-available:before {
    font-family: fontawesome;
    content: "\f00d";
    color: #fff; }

.orange {
  background: #ff9f1a; }

.green {
  background: #85ad00; }

.blue {
  background: #0076ad; }

.tooltip-inner {
  padding: 1.3em; }

.quantity {
  width: 15%;
  padding-left: 6px;
}

@-webkit-keyframes opacity {
  0% {
    opacity: 0;
    -webkit-transform: scale(3);
            transform: scale(3); }
  100% {
    opacity: 1;
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes opacity {
  0% {
    opacity: 0;
    -webkit-transform: scale(3);
            transform: scale(3); }
  100% {
    opacity: 1;
    -webkit-transform: scale(1);
            transform: scale(1); } }

/*# sourceMappingURL=style.css.map */

.hideMe{
    display: none;
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center" style="padding-left:0; padding-right:0;">
                                    <h4 class="page-title">&nbsp;</h4>
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">
                                                 <li class="float-left"><p class="page-title"> <strong>Product Detail</strong></p></li>

                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'customer/index.php'?>">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'customer/index.php?page=products'?>">Product Detail</a></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->


        <!--============================================================-->
                                <!-- Start Top Area  -->
        <!--============================================================-->

        <div class="row product-top">
            <div class="col-sm-10">
                
            </div>    
            <div class="col-sm-2">
                <a href="<?=BASE_URL.'customer/index.php?page=cart'?>" class="cart-btn float-right cart-area">
                    <i class="fa fa-shopping-cart fa-2x"></i>
                    <span class="cart-count"><?=$total_quantity?$total_quantity:0?></span>
                </a>
            </div>

        </div>

        <!--============================================================-->
                                <!-- End Top Area -->
        <!--============================================================-->


        <!--============================================================-->
                            <!-- Cart Product Start -->
        <!--============================================================-->



                        <div class="row">
                          <div class="card">
                            <div class="container-fliud">
                                    <div class="wrapper row">
                                        <div class="preview col-md-6">
                                          
                                          <div class="preview-pic tab-content">

                                          <?php  
                                          
                                          $userid = Helper::getUserId();
                                          $user = Helper::getCustomerById($userid);
                                          $priceArray = array();
                                          $custPrice = 0.0000;
                                          $cover_image = BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png';
                                          $tabPanelHtml = '';
                                          $tabHtml = '';
                                          // prx($user);
                                          if(isset($product->prices) && !empty($product->prices)) {
                                            foreach($product->prices as $price) {
                                                if($price->custgroup_id==$user->custgroup_id) {
                                                    $custPrice = $price->product_price;
                                                }
                                            }
                                            if(empty($custPrice)) {
                                                $default_group = Helper::defaultCustomerGroup();
                                                if(isset($default_group->custgroup_id) && !empty($default_group->custgroup_id)) {
                                                    foreach($product->prices as $price) {
                                                        if($price->custgroup_id==$default_group->custgroup_id) {
                                                            $custPrice = $price->product_price;
                                                        }
                                                    }
                                                }
                                            }
                                        } 

                                        


                                            if(isset($product->images) && !empty($product->images)) {
                                              foreach($product->images as $key=>$img) {
                                                
                                                if($img->file_cover == 1) {
                                                    $cover_image = BASE_URL.UPLOAD_IMAGE_PATH.$img->file_name;

                                                    $tabPanelHtml .= '<div class="tab-pane active" id="pic-'.$key.'"><img src="'.$cover_image.'" /></div>';
                                                  
                                                    $tabHtml .= '<li class="active"><a data-target="#pic-'.$key.'" data-toggle="tab"><img src="'.$cover_image.'" width="85" height="80" /></a></li>';
                                              
                                                }else {
                                                  $image = BASE_URL.UPLOAD_IMAGE_PATH.$img->file_name;

                                                  $tabPanelHtml .= '<div class="tab-pane " id="pic-'.$key.'"> <img src="'.$image.'" /></div>'; 
                                                  
                                                  $tabHtml .= '<li class=""><a data-target="#pic-'.$key.'" data-toggle="tab"><img src="'.$image.'" width="85" height="80" /></a></li>';
                                                }
                                                

                                              }

                                            }
                                            
                                            
                                            
                                            
                                            ?>

                                            <?=$tabPanelHtml?>
                                            <ul class="preview-thumbnail nav nav-tabs">
                                            <?=$tabHtml?>
                                            </ul>
                                            </div>    
                                        </div>
                                        <div class="details col-md-6">
                                            <h3 class="product-title"><?=$product->product_name?></h3>
                                            <!-- <div class="rating">
                                                <div class="stars">
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                </div>
                                                <span class="review-no">41 reviews</span>
                                            </div> -->
                                            <p class="product-description"><?=$product->product_description?></p>
                                            <div class="quantity-main">Quantity : <input type="number" name="quantity" class="quantity" value="1" ></div>
                                            <h4 class="price">current price: <span>$<?=$custPrice?></span></h4>
                                            
                                            <div class="action">
                                                <button class="add-to-cart btn btn-default" type="button" data-id="<?=$product->product_id?>">add to cart</button>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <!-- Cart Product End -->
                        
                        
                </section>      
                </section>      
               
                <script>

// Add product to cart 
$(document).on('click', '.add-to-cart', function(e){
    e.preventDefault();
    let quantity = $('.quantity-main .quantity').val();
    let product_id = $(this).attr('data-id');
    
    $.ajax({
        type: 'post',
        url: '../include/ajax.php', 
        data: {'product_id':product_id, 'quantity':quantity, 'task':'submit_addtocart'},
        dataType: 'json',
        beforeSend: function() {
            $('.loader').show(); 
        },
        complete: function() {
            $('.loader').hide();
        },
        success: function (response) {
            if(response.success) {
              $('.cart-count').text(response.total_quantity);
            }
            alert(response.message);
            
            
        }
    });
});


</script>