<?php
$products = Helper::getAllProductsDetail();
$total_quantity = Helper::getCartCount();
?>

<style>
.card-product .img-wrap {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 220px;
    text-align: center;
}
.card-product .img-wrap img {
    max-height: 100%;
    max-width: 100%;
    object-fit: cover;
}
.card-product .info-wrap {
    overflow: hidden;
    padding: 15px;
    border-top: 1px solid #eee;
}
.card-product .bottom-wrap {
    padding: 15px;
    border-top: 1px solid #eee;
    display: flex;
}

.label-rating { margin-right:10px;
    color: #333;
    display: inline-block;
    vertical-align: middle;
}

.card-product .price-old {
    color: #999;
}
.float-right {
    float: right;
}
.product-top {
    padding: 20px 10px;
}
.cart-area {
    position: relative;
    padding-right: 27px;
}
.cart-count {
    position: absolute;
    top: -18px;
    background: red;
    color: #fff;
    padding: 3px 6px;
    border-radius: 50%;
}
.hideMe{
    display: none;
}
.float-left {
    float: left;
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center">
                                <h4 class="page-title">&nbsp;</h4>
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">

                                            <li class="float-left"><p class="page-title"> <strong>Products</strong></p></li>
                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'customer/index.php'?>">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'customer/index.php?page=products'?>">Products</a></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->

        <!--============================================================-->
                                <!-- Start Top Area  -->
        <!--============================================================-->

        <div class="row product-top">
            <div class="col-sm-10">
                
            </div>    
            <div class="col-sm-2">
                <a href="<?=BASE_URL.'customer/index.php?page=cart'?>" class="cart-btn float-right cart-area">
                    <i class="fa fa-shopping-cart fa-2x"></i>
                    <span class="cart-count"><?=$total_quantity?$total_quantity:0?></span>
                </a>
            </div>

        </div>

        <!--============================================================-->
                                <!-- End Top Area -->
        <!--============================================================-->

        

                        <!-- Cart Product Start -->


                        <div class="row" style="margin-top: 1em;">
                            <?php 
                            $userid = Helper::getUserId();
                            $user = Helper::getCustomerById($userid);
                            foreach($products as $key=>$product) { 
                                
                                $imgArray = array();
                                $priceArray = array();
                                $custPrice = 0.0000;
                                $cover_image = BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png';
                                
                                if(isset($product->images) && !empty($product->images)) {
                                    $imgArray = $product->images;
                                    if($imgArray[0]->file_cover == 1) {
                                        $cover_image = BASE_URL.UPLOAD_IMAGE_PATH.$imgArray[0]->file_name;
                                    }
                                }    
                                // prx($user);
                                if(isset($product->prices) && !empty($product->prices)) {
                                    foreach($product->prices as $price) {
                                        if($price->custgroup_id==$user->custgroup_id) {
                                            $custPrice = $price->product_price;
                                        }
                                    }
                                    if(empty($custPrice)) {
                                        $default_group = Helper::defaultCustomerGroup();
                                        if(isset($default_group->custgroup_id) && !empty($default_group->custgroup_id)) {
                                            foreach($product->prices as $price) {
                                                if($price->custgroup_id==$default_group->custgroup_id) {
                                                    $custPrice = $price->product_price;
                                                }
                                            }
                                        }
                                    }
                                } 

                                
                                
                            ?>
                            <div class="col-md-3">
                                <figure class="card card-product">
                                    <a href="<?=BASE_URL.'customer/index.php?page=product_detail&id='.$product->product_id?>">
                                        <div class="img-wrap">
                                            <img src="<?=$cover_image?>" width="100%">
                                        </div>
                                        
                                        <figcaption class="info-wrap">
                                                <h4 class="title"><?=$product->product_name?></h4>
                                                <span class="price-new">$<?=$custPrice?></span> 
                                        </figcaption>
                                    </a>
                                    <!-- <div class="bottom-wrap">
                                        <div class="col-sm-6 col-xs-6">
                                            <div class="price-wrap h5">
                                                <span class="price-new"><?=$custPrice?></span> 
                                            </div> 
                                        </div>
                                        <div class="col-sm-6 col-xs-6">
                                            <a href="javascript:void(0)" class="btn btn-sm btn-primary float-right add-to-cart" data-id="<?=$product->product_id?>">Add To Cart</a>	
                                        </div>
                                    </div> -->
                                </figure>
                            </div> <!-- col // -->
                            <?php } ?>
                            
                        </div> <!-- row.// -->



                        <!-- Cart Product End -->
                        
                        
                </section>      
                </section>      
               
