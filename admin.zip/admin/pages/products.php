<?php

$parentCategories = Helper::getParentCategories();
$allCategories = Helper::getAllCategories();
$customerGroup = Helper::getCustomerGroup();
$products = Helper::getProducts();
$productData = Helper::getProductDetail();
$categoryTree = helper::getCategoryTree();

?>

<style>

.td-w-25 {
    width:25% !important;
}
.td-w-60 {
    width:60% !important;
}
.view-table>tbody>tr>td{
    border: none;
}
.cover_photo {
    width:150px; 
    height:124px; 
    padding:20px
}
.generalInfo_coverID {
    border: solid 5px #4ecdc4;
    background-color: #808080;
}
.required-element {
    color: red;
}

.category-body {
    margin-top: 15px;
}

.add-category-tab {
    position: absolute;
    top: 12px;
    right: 35px;
    z-index: 999;
}
.hideMe{
    display: none;
}
.sub-category-option {
    display: none;
}
.sub-category {
    margin-left: 1px;
}
.sub-category-style {
    margin-left: 5px;
}
.main-category {
    font-weight: 600;
}
.removeImage {
    color: red;
    position: relative;
    float: right;
}
.cover-photo {
    border: solid 3px red !important;
}
.image-main{
    background-color: #000;
    margin-left: 15px;
    margin-right: 15px;
    margin-top: 10px;
    border-top-right-radius: 4px;
    border-top-left-radius: 4px;
    padding-right: 0px;
    padding-left: 0px;
    border: solid 3px #fff;
}
.currency-sign {
    background-color: #eee;
    padding: 7px;
    position: absolute;
    top: 1px;
    right: 16px;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}

@media only screen and (max-width: 768px) {
    .image-main{
        background-color: #000;
        margin-left: 0px;
        margin-right: 0px;
        margin-top: 10px;
        border-top-right-radius: 4px;
        border-top-left-radius: 4px;
        padding-right: 0px;
        padding-left: 0px;
        border: solid 3px #fff;
    }

    #generalInfo {
        margin: 15px 0px !important;
    }
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center" style="padding-left:0; padding-right:0;">
                                    <h4 class="page-title">&nbsp;</h4>
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">
                                                <li class="float-left"><p class="page-title"> <strong>Products</strong></p></li>
                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'admin/index.php'?>">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'admin/index.php?page=products'?>">Products</a></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->

                        <div class="row category-body" >

        <!--============================================================-->
                                <!-- Start Body Left  -->
        <!--============================================================-->

                                <div class="col-md-6 content-panel">
                                    <div class="card">
                                        
                                        <!-- Category Table Start -->
                                        <span class="nav-item add-category-tab"> 
                                            <a href="<?=BASE_URL.'admin/index.php?page=products&product=0'?>" id="toggleProductFormButton">
                                                <span class="hidden-xs-down"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                            </a> 
                                        </span>
                                        <div class="">
                                        <div class="adv-table">
                                            <table table cellpadding="0" cellspacing="0" border="0" class="display table" id="hidden-table-info">
                                                <thead>
                                                    <tr>
                                                        <th style="width:80px">No</th>
                                                        <th>Product</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                <?php
                                                $count = 1;
                                                foreach($products as $key=>$product) {
                                                    
                                                ?>
                                                    <tr>
                                                        <td><?=$count;?></td>
                                                        <td><?=$product->product_name;?></td>
                                                        <td>
                                                            <!-- Edit Button -->
                                                        <a href="<?=BASE_URL.'admin/index.php?page=products&product='.$product->product_id?>" class="btn btn-success btn-xs updateProduct" data-id="<?=$product->product_id?>"> 
                                                            <i class="fa fa-pencil"></i>
                                                        </a>
                                                         <!-- View Button -->
                                                         <a class="btn btn-info btn-xs viewProduct" data-id="<?=$product->product_id?>" data-toggle="modal" data-target="#viewProductModal" >
                                                            <i class="fa fa-eye "></i>
                                                        </a>
                                                            <!-- Delete Button -->
                                                        <a class="btn btn-danger btn-xs removeProduct" data-id="<?=$product->product_id?>">
                                                            <i class="fa fa-trash "></i>
                                                        </a>
                                                        </td>
                                                    </tr>
                                                <?php $count++; } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        </div>
                                    </div>
                               </div>
                  
        <!--============================================================-->
                                <!-- End Body Left  -->
        <!--============================================================-->
        
        
        <!--============================================================-->
                                <!-- Start Body Right  -->
        <!--============================================================-->        

                            <div class="col-md-6 <?=isset($_GET['product'])?'':'hideMe'?>" id="categoryForm" style="padding-right:0;">
                                <!-- Tabs -->
                                <form class="form-horizontal style-form" name="product_form" method="POST" id="product_form" action="../include/store.php" enctype="multipart/form-data">
                                    <div class="card">
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs custum-tabs">
                                            <li class="nav-item active"> 
                                                <a class="nav-link active" href="javascript:void(0)" role="tab">
                                                    <span class="hidden-xs-down">Add Product</span>
                                                </a> 
                                            </li>
                                        </ul>
                                        <!-- Tab panes -->
                                        <div class="tab-content form-panel" style="padding:0px; box-shadow:none;">
                                            <div class="tab-pane active" role="tabpanel">

                                                <div class="form-group row">
                                                    <label for="product_name" class="col-sm-3 text-right control-label col-form-label">Product Name</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" name="product_name" class="form-control" id="product_name" placeholder="Enter Product Name" value="<?=$productData->product_name?>">
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group row">
                                                    <label for="product_quantity" class="col-sm-3 text-right control-label col-form-label">Product Quantity</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" name="product_quantity" class="form-control" id="product_quantity" placeholder="Enter Product Quantity" value="<?=$productData->product_quantity?>">
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="product_description" class="col-sm-3 text-right control-label col-form-label">Product Description</label>
                                                    <div class="col-sm-7">
                                                        <textarea name="product_description" class="form-control"><?=$productData->product_description?></textarea>
                                                        <script>
                                                            CKEDITOR.replace( 'product_description' );
                                                        </script>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="parent_id" class="col-sm-3 text-right control-label col-form-label">Category</label>
                                                    <div class="col-sm-7">
                                                        
                                                <?php
                                                $categoryArray = explode(',', $productData->category_id);
                                                foreach($categoryTree as $key=>$val) {
                                                    $checked = (in_array($val->category_id, $categoryArray))?' checked':'';
                                                ?>
                                                        <div class="row main-category">
                                                            <div class="col-sm-6">
                                                                <input type="checkbox" name="category_id[]" value="<?=$val->category_id?>" <?=$checked?>><span>&nbsp;<?=$val->category_name?></span>
                                                            </div>
                                                        </div>
                                                        <div class="row sub-category">
                                                <?php
                                                    
                                                foreach($val->child_category as $key1=>$val1) {
                                                    $checked = (in_array($val1->category_id, $categoryArray))?' checked':'';
                                                ?>
                                                        
                                                            <div class="col-sm-6">
                                                                <input type="checkbox" name="category_id[]" value="<?=$val1->category_id?>" <?=$checked?>><span>&nbsp;<?=$val1->category_name?></span>
                                                            </div>

                                                <?php } ?>

                                                        </div>
                                                <?php } ?>
                                                    </div>
                                                </div>

                                            <?php 
                                                $priceTxt = 'Price';
                                                for($i=0; $i<4; $i++) {
                                                    $priceGroup = new stdClass();
                                                    $priceGroup->custgroup_id = '';
                                                    $priceGroup->product_price = '';
                                                    if(isset($productData->prices[$i])){
                                                        $priceGroup = $productData->prices[$i];
                                                    }
                                            ?>
                                                <div class="form-group row">
                                                    <label for="customer_group" class="col-sm-3 text-right control-label col-form-label"><?=$priceTxt?></label>
                                                    <div class="col-sm-4">
                                                        <select class="form-control" name="customer_group[]" id="customer_group">
                                                        <option value="0">Select Option</option>
                                                        <?php
                                                        $options = $customerGroup;
                                                        foreach($options as $key=>$option) {
    
                                                            $selected = ($priceGroup->custgroup_id==$option->custgroup_id)?' selected':'';
                                                            echo '<option class="" value="'.$option->custgroup_id.'" '.$selected.'>'.$option->custgroup_name.'</option>';
    
                                                        }
                                                        
                                                        ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <input type="text" name="price[]" class="form-control" placeholder="Price" value="<?=$priceGroup->product_price?>"><span class="currency-sign">$</span>
                                                    </div>
                                                </div>
                                                
                                            <?php 
                                            
                                                $priceTxt = '';        
                                                } 
                                                
                                            ?>

                                                <div class="form-group row">
                                                    <label for="photo_upload" class="col-sm-3 text-right control-label col-form-label">Photo Upload</label>
                                                    <div class="col-sm-7">
                                                        <input type="file" name="photo_upload[]" class="form-control" id="photo_upload" multiple>
                                                    </div>
                                                </div> 

                                                <div class="form-group row image-row">
                                                <?php  
                                                $coverPhoto = '';
                                                if(isset($productData->images)){ 
                                                foreach($productData->images as $k=>$img) {
                                                    $coverPhotoClass = '';
                                                    $coverPhoto_tooltip = '';
                                                    if($img->file_cover) {
                                                        $coverPhoto = 1;
                                                        $coverPhotoClass = 'cover-photo';
                                                        $coverPhoto_tooltip = 'data-toggle="tooltip" title="Cover Photo!"';
                                                    }
                                                ?>
                                                <div class="col-sm-3 col-xs-6 image-main <?=$coverPhotoClass?>" style="margin-top: 10px;" <?=$coverPhoto_tooltip?>>
                                                    <a href="javascript::void()" class="removeImage" data-id="<?=$img->file_id?>" ><i class="fa fa-times fa-1x "></i></a>
                                                    <img src="<?=BASE_URL.UPLOAD_IMAGE_PATH.$img->file_name?>" alt="Los Angeles" style="width:100%; height:60px" class="img-main">
                                                </div>
                                                <?php } } ?>
                                            </div>

                                                <div id="GIcoverPhotoLabel">
                                                
                                                </div>

                                            </div>

                                            
                                            <div class="row" style="padding-bottom:20px">
                                                <div class="col-sm-3"></div>
                                                <div class="card-body col-sm-7" >
                                                    <input type="submit" name="submit_product" class="btn btn-primary" id="submit_product" value="<?=($productData->product_id)?'Update':'Add'?>"  style="width:100%"/>
                                                </div>
                                            </div>

                                            <!-- Hidden Field -->
                                            <input type="hidden" name="product_id" id="product_id" value="<?=$productData->product_id?>">
                                        </div>
                                    </div>
                                </form>
                            </div>

        <!--============================================================-->
                                <!-- End Body Right  -->
        <!--============================================================-->

                        </div> 
                        
                        
                </section>      
                </section>   

                
    <!-- Preview Image Modal -->
    <div id="imagePreviewModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close closeModal">&times;</button>
            <h4 class="modal-title">Select Cover Photo</h4>
            </div>
            <div class="modal-body" id="imagePreviewBody">
                <div class="center">
                    <img src="<?=BASE_URL.SITE_IMAGE_PATH.'straight-loader.gif'?>" width="100px">
                </div>                                    
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-default closeModal">Close</button>
            </div>
        </div>

        </div>
    </div>  
    
    <!-- View Product Modal -->
    <div id="viewProductModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Product Detailed</h4>
            </div>
            <div class="modal-body" id="viewProductModalBody">
                <div class="center">
                    <img src="<?=BASE_URL.SITE_IMAGE_PATH.'straight-loader.gif'?>" width="100px">
                </div>
            </div>
            <div class="modal-footer" style="border:none">
            <button type="button" class="btn btn-default" data-dismiss="modal" style="margin-top:20px">Close</button>
            </div>
        </div>

        </div>
    </div>  
               
                
<script>

    // Handle Sub Categories

    $(document).on('change', '#parent_id', function(){
        let parentId = $(this).val();
        // console.log('parentId  : ', parentId);
        // alert('parentId  : ', parentId);
        if(parentId){
            $('.sub-category-option').hide();
            className = '.subCatOption'+parentId;
            $(className).show();
        }

    });

    // Remove Category Ajax

    $(document).on('click', '.removeProduct', function(e){
        e.preventDefault();
        if(!confirm("Do you want to remove this Product!")) {
            return false;
        }
        let this_tr = $(this).closest('tr');
        let product_id = $(this).attr('data-id');

        $.ajax({
            type: 'post',
            url: '../include/ajax.php', 
            data: {'product_id':product_id, 'task':'removeProduct'},
            dataType: 'json',
            beforeSend: function() {
                $('.loader').show();
            },
            complete: function() {
                $('.loader').hide();
            },
            success: function (response) {
                if(response.success) {
                    this_tr.remove();
                }else {
                    alert(response.message);
                }
                document.location.reload();
            }
        });
    }); 


    // Open image preview modal
                    
    $('#photo_upload').on('change', function() {
        let isCoverPhoto = $(this).closest('form').find('.cover-photo').length;
        if(isCoverPhoto>0){
            return false;
        }
        $('#imagePreviewBody').empty();
        $('#imagePreviewModal').modal('toggle');
        imagesPreview(this, '#imagePreviewBody');
    });

    // Modal not close if no cover photo selected

    $(document).on('click', '.closeModal', function(){
        let thisModal = $(this).closest('#imagePreviewModal');
        if( !(thisModal.find('img').hasClass('generalInfo_coverID')) ) {
            alert("Please select cover photo");
            return false;
        }else{
            $('#imagePreviewModal').modal('toggle');
        }
    });  

    // Image Preview Display

    var imagesPreview = function(input, placeToInsertImagePreview, layoutNo=0) {
        if (input.files) {
            var filesAmount = input.files.length;
            
            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
            
                let fileName = input.files[i].name;
                reader.onload = function(event) {
                    $($.parseHTML('<img class="cover_photo" data-name ="'+fileName+'" data-layout="'+layoutNo+'" src="'+event.target.result+'">')).appendTo(placeToInsertImagePreview);
                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    // Select Photo as cover Photo From preview Modal

    $(document).on('click', '.cover_photo', function(){
        let layoutNo = $(this).attr('data-layout');
        if($(this).hasClass('generalInfo_coverID')) {
            $(this).removeClass('generalInfo_coverID');
            if(layoutNo==0) {
                $('#GIcoverPhotoLabel').empty();
            }else{
                $('#unitInfo'+layoutNo).find('.UIcoverPhotoLabel').empty();
            }
            return false;
        }      
        let photoName = $(this).attr('data-name');
        let checkedCount = $('.generalInfo_coverID').length;
        
        if(checkedCount>0) {
            alert("You can select one image as cover photo");
            return false;
        }
        if(layoutNo==0) {
            $('#GIcoverPhotoLabel').empty();
        }else{
            $('#unitInfo'+layoutNo).find('.UIcoverPhotoLabel').empty();
        }
        let isChecked = $(this).hasClass('generalInfo_coverID');
        if(!isChecked) {
            $(this).addClass('generalInfo_coverID');
            let coverHtml = '<input type="hidden" name="cover_photo" value="'+photoName+'">';
            if(layoutNo==0) {
                $('#GIcoverPhotoLabel').append(coverHtml);
            }else{
                let index = layoutNo-1;
                let coverHtml = '<input type="hidden" name="unit_info_cover_photo['+index+']" value="'+photoName+'">';
                $('#unitInfo'+layoutNo).find('.UIcoverPhotoLabel').append(coverHtml);
            }
            
        }else{
            $(this).removeClass('generalInfo_coverID');
            if(layoutNo==0) {
                $('#GIcoverPhotoLabel').empty();
            }else{
                $('#unitinfo'+layoutNo).find('.UIcoverPhotoLabel').empty();
            }
        }
        
    });

    // remove Image AJAX

    $(document).on('click', '.removeImage', function(e){
        e.preventDefault();
        if(!confirm("Do you want to remove this image permanently!")) {
            return false;
        }
        let onThis = $(this).closest('.image-main');
        let file_id = $(this).attr('data-id');

        // AJAX request
        $.ajax({
            type: 'post',
            url: '../include/ajax.php', 
            data: {'task':'removeImage', 'file_id':file_id},
            dataType: 'json',
            
            beforeSend: function() {
                $('.loader').show();
            },

            complete: function() {
                $('.loader').hide();
            },
            success: function (response) {
                if(response.success) {
                    onThis.remove();
                }
            }
        });
    });

    // Add image as cover photo

    $(document).on('click', '.img-main ', function(){
        let form = $(this).closest('form');
        let selected_photo = $(this);
        let file_id = selected_photo.closest('.image-main').find('a').attr('data-id');
        let product_id = form.find('input[name=product_id]').val();
        
        // AJAX request
        $.ajax({
            type: 'post',
            url: '../include/ajax.php', 
            data: {'task':'updateCoverPhoto', 'product_id':product_id, 'file_id':file_id},
            dataType: 'json',

            beforeSend: function() {
                $('.loader').show();
            },

            complete: function() {
                $('.loader').hide();
            },
            success: function (response) {
                if(response.success) {
                    form.find('.cover-photo').removeClass('cover-photo');
                    selected_photo.closest('.image-main').addClass('cover-photo');
                }else{
                    alert('Cover photo not updated, Plaese try again!');
                }
            }
        });

    });

    // View Detail Ajax On Modal Body 

    $(document).on('click', '.viewProduct ', function(){
        let form = $(this).closest('form');
        let product_id = $(this).attr('data-id');
        
        // AJAX request
        $.ajax({
            type: 'post',
            url: '../include/ajax.php', 
            data: {'task':'viewProductModalData', 'product_id':product_id},
            dataType: 'json',

            // beforeSend: function() {
            //     $('.loader').show();
            // },

            // complete: function() {
            //     $('.loader').hide();
            // },
            success: function (response) {
                if(response.success) {
                    // $('#viewProductModalBody').empty();
                    $('#viewProductModalBody').html(response.html);
                }else{
                    alert('Cover photo not updated, Plaese try again!');
                }
            }
        });

    });
    
    $(document).on('click', '#submit_product', function(){
        let coverImg = $(this).closest('form').find('.cover-photo').length;
        let coverImgUploaded = $(this).closest('form').find('input[name=cover_photo]').length;
        if(coverImg==0 && coverImgUploaded==0) {
            alert("Please select cover photo");
            return false;
        }
    });

</script>

<script type="text/javascript">
    $(document).ready(function() {
      /*
       * Insert a 'details' column to the table
       */
      var nCloneTh = document.createElement('th');
      var nCloneTd = document.createElement('td');
    //   nCloneTd.innerHTML = '<img src="lib/advanced-datatable/images/details_open.png">';
    //   nCloneTd.className = "center";
      nCloneTd.className = "hideMe";
      nCloneTh.className = "hideMe";

      $('#hidden-table-info thead tr').each(function() {
        this.insertBefore(nCloneTh, this.childNodes[0]);
      });

      $('#hidden-table-info tbody tr').each(function() {
        this.insertBefore(nCloneTd.cloneNode(true), this.childNodes[0]);
      });

      /*
       * Initialse DataTables, with no sorting on the 'details' column
       */
      var oTable = $('#hidden-table-info').dataTable({
        "bFilter" : false,               
        "bLengthChange": false,
        "searching": false,
        "aoColumnDefs": [{
          "bSortable": false,
          "aTargets": [0]
        }],
        "aaSorting": [
          [1, 'asc']
        ]
      });

    });
  </script>o