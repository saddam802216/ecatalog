<?php
// $categoryTree = helper::getCategoryTree();
$parentCategories = Helper::getParentCategories();
$allCategories = Helper::getAllCategories();


?>

<style>
.general_info_cover_photo {
    width:150px; 
    height:124px; 
    padding:20px
}
.generalInfo_coverID {
    border: solid 5px #4ecdc4;
    background-color: #808080;
}
.required-element {
    color: red;
}

.category-body {
    margin-top: 15px;
}

.add-category-tab {
    position: absolute;
    top: 12px;
    right: 35px;
    z-index: 999;
}
.hideMe{
    display: none;
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center" style="padding-left:0; padding-right:0;">
                                    <h4 class="page-title">&nbsp;</h4>
                                    
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">
                                                <li class="float-left"><p class="page-title"> <strong>Categories</strong></p></li>
                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'admin/index.php'?>">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'admin/index.php?page=category'?>">Category</a></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->

                        <div class="row category-body" >

        <!--============================================================-->
                                <!-- Start Body Left  -->
        <!--============================================================-->

                                <div class="col-md-6 content-panel">
                                    <div class="card">
                                        <!-- Nav tabs -->
                                        <!-- <ul class="nav nav-tabs custum-tabs">
                                            <li class="nav-item add-category-tab"> 
                                                <a href="javascript:void(0)" id="toggleCategoryFormButton">
                                                    <span class="hidden-xs-down"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                                </a> 
                                            </li>
                                        </ul> -->
                                        <!-- Category Table Start -->
                                        <span class="nav-item add-category-tab"> 
                                            <a href="javascript:void(0)" id="toggleCategoryFormButton">
                                                <span class="hidden-xs-down"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                            </a> 
                                        </span>
                                        <div class="">
                                            <div class="adv-table">
                                            <table table cellpadding="0" cellspacing="0" border="0" class="display table" id="hidden-table-info">
                                                <thead>
                                                    <tr>
                                                        <th style="width:80px">No</th>
                                                        <th>Category</th>
                                                        <!-- <th>Parent Category</th> -->
                                                        <th class="sorting_disabled">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                <?php
                                                $count = 1;
                                                foreach($allCategories as $key=>$category) {
                                                    $prefix = ($category->parent_id) ? ' + ' : '';
                                                ?>
                                                    <tr>
                                                        <td><?=$count.'.';?></td>
                                                        <td><?=$prefix.$category->category_name;?></td>
                                                        <!-- <td><=$category->parent_name;?></td> -->
                                                        <td>
                                                            <!-- Edit Button -->
                                                        <button class="btn btn-success btn-xs updateCategory" data-id="<?=$category->category_id?>"> 
                                                            <i class="fa fa-pencil"></i>
                                                        </button>
                                                            <!-- Delete Button -->
                                                        <button class="btn btn-danger btn-xs removeCategory" data-id="<?=$category->category_id?>">
                                                            <i class="fa fa-trash "></i>
                                                        </button>
                                                        </td>
                                                    </tr>
                                                <?php $count++; } ?>
                                                </tbody>
                                            </table>
                                            </div>
                                        </div>
                                    </div>
                               </div>
                  
        <!--============================================================-->
                                <!-- End Body Left  -->
        <!--============================================================-->
        
        
        <!--============================================================-->
                                <!-- Start Body Right  -->
        <!--============================================================-->        

                            <div class="col-md-6 hideMe" id="categoryForm" style="padding-right: 0;">
                                <!-- Tabs -->
                                <form class="form-horizontal style-form" name="category_form" method="POST" id="category_form" action="../include/store.php" enctype="multipart/form-data">
                                    <div class="card">
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs custum-tabs">
                                            <li class="nav-item active"> 
                                                <a class="nav-link active" href="javascript:void(0)" role="tab">
                                                    <span class="hidden-xs-down">Add Category</span>
                                                </a> 
                                            </li>
                                        </ul>
                                        <!-- Tab panes -->
                                        <div class="tab-content form-panel" style="padding:0px; box-shadow:none;">
                                            <div class="tab-pane active" role="tabpanel">
                                                <div class="form-group row">
                                                    <label for="parent_id" class="col-sm-3 text-right control-label col-form-label">Parent<span class="required-element">*</span></label>
                                                    <div class="col-sm-7">
                                                        <select class="form-control" name="parent_id" id="parent_id">
                                                        <option value="0">Root</option>
                                                        <?php
                                                        $options = $parentCategories;
                                                        foreach($options as $key=>$option) {
                                                            echo '<option value="'.$option->category_id.'">'.$option->category_name.'</option>';
                                                        }
                                                        
                                                        ?>
                                                        </select>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label for="category_name" class="col-sm-3 text-right control-label col-form-label">Enter Category</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" name="category_name" class="form-control" id="category_name" value="">
                                                    </div>
                                                </div> 
                                            </div>
                                            
                                            <div class="row" style="padding-bottom:20px">
                                                <div class="col-sm-3"></div>
                                                <div class="card-body col-sm-7" >
                                                    <input type="submit" name="submit_category" class="btn btn-primary" id="submit_category" value="Add" style="width:100%"/>
                                                </div>
                                            </div>

                                            <!-- Hidden Field -->
                                            <input type="hidden" name="category_id" id="category_id" value="">
                                        </div>
                                    </div>
                                </form>
                            </div>

        <!--============================================================-->
                                <!-- End Body Right  -->
        <!--============================================================-->

                        </div> 
                        
                        
                </section>      
                </section>      
               
                
<script>

    // Toggling Add Category Form
    
    $(document).on('click', '#toggleCategoryFormButton', function(){
        $('#parent_id').val(0);
        $('#category_name').val('');
        $('#category_id').val('');
        $('#submit_category').val('Add');
        $('#categoryForm').show();
    });
        
    // Update Category Ajax

    $(document).on('click', '.updateCategory', function(e){
        e.preventDefault();
        let category_id = $(this).attr('data-id');
        $('#categoryForm').show();
        $.ajax({
            type: 'post',
            url: '../include/ajax.php', 
            data: {'category_id':category_id, 'task':'updateCategory'},
            dataType: 'json',
            beforeSend: function() {
                $('.loader').show();
            },
            complete: function() {
                $('.loader').hide();
            },
            success: function (response) {
                if(response.success) {
                    $('#parent_id').val(response.category.parent_id);
                    $('#category_name').val(response.category.category_name);
                    $('#category_id').val(response.category.category_id);
                    $('#submit_category').val('Update');
                }else {
                    alert(response.message);
                }
                
            }
        });
    }); 


    // Remove Category Ajax

    $(document).on('click', '.removeCategory', function(e){
        e.preventDefault();
        if(!confirm("Do you want to remove this category!")) {
            return false;
        }
        let this_tr = $(this).closest('tr');
        let category_id = $(this).attr('data-id');

        $.ajax({
            type: 'post',
            url: '../include/ajax.php', 
            data: {'category_id':category_id, 'task':'removeCategory'},
            dataType: 'json',
            beforeSend: function() {
                $('.loader').show();
            },
            complete: function() {
                $('.loader').hide();
            },
            success: function (response) {
                if(response.success) {
                    this_tr.remove();
                }else {
                    alert(response.message);
                }
                
            }
        });
    }); 

    $('#hidden-table-info').dataTable({
        "searching": false
    });

</script>

<script type="text/javascript">
    $(document).ready(function() {
      /*
       * Insert a 'details' column to the table
       */
      var nCloneTh = document.createElement('th');
      var nCloneTd = document.createElement('td');
    //   nCloneTd.innerHTML = '<img src="lib/advanced-datatable/images/details_open.png">';
    //   nCloneTd.className = "center";
      nCloneTd.className = "hideMe";
      nCloneTh.className = "hideMe";

      $('#hidden-table-info thead tr').each(function() {
        this.insertBefore(nCloneTh, this.childNodes[0]);
      });

      $('#hidden-table-info tbody tr').each(function() {
        this.insertBefore(nCloneTd.cloneNode(true), this.childNodes[0]);
      });

      /*
       * Initialse DataTables, with no sorting on the 'details' column
       */
      var oTable = $('#hidden-table-info').dataTable({
        "bFilter" : false,               
        "bLengthChange": false,
        "searching": false,
        "aoColumnDefs": [{
          "bSortable": false,
          "aTargets": [0]
        }],
        "aaSorting": [
          [1, 'asc']
        ]
      });

    });
  </script>
