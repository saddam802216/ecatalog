<?php

// $customers = Helper::getCustomers();
// $customerGroup = Helper::getCustomerGroup();

$orders = Helper::getAllOrders();

?>

<style>
.general_info_cover_photo {
    width:150px; 
    height:124px; 
    padding:20px
}
.generalInfo_coverID {
    border: solid 5px #4ecdc4;
    background-color: #808080;
}
.required-element {
    color: red;
}

.category-body {
    margin-top: 15px;
}

.add-category-tab {
    float: right !important;
}
.hideMe{
    display: none;
}
</style>

        <!-- ============================================================== -->
                                <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <section id="main-content">
                    <section class="wrapper">

        <!--============================================================-->
                                <!-- Start Breadcrumb  -->
        <!--============================================================-->                    
                        <div class="page-breadcrumb">
                            <div class="row">
                                <div class="col-md-12 d-flex no-block align-items-center" style="padding-left:0; padding-right:0;">
                                    <h4 class="page-title">&nbsp;</h4>
                                    <div class="ml-auto text-right">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb" style="margin-bottom:0;">
                                                <li class="float-left"><p class="page-title"> <strong>Orders</strong></p></li>
                                                <li class="breadcrumb-item"><a href="<?=BASE_URL.'admin/index.php'?>">Home</a></li>
                                                <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'admin/index.php?page=orders'?>">Orders</a></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>

        <!--============================================================-->
                                <!-- End Breadcrumb  -->
        <!--============================================================-->

                        <div class="row category-body" >
                                    <?php //prx($orders); ?>
        <!--============================================================-->
                                <!-- Start Body Left  -->
        <!--============================================================-->

                                <div class="col-md-6 content-panel">
                                    <div class="card">
                                        <!-- Nav tabs -->
                                        <!-- <ul class="nav nav-tabs custum-tabs">
                                            <li class="nav-item add-category-tab"> 
                                                <a href="javascript:void(0)" id="toggleCategoryFormButton">
                                                    <span class="hidden-xs-down"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                                </a> 
                                            </li>
                                        </ul> -->
                                        <!-- Category Table Start -->
                                        
                                        <div class="adv-table">
                                        <table table cellpadding="0" cellspacing="0" border="0" class="display table" id="hidden-table-info">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Order Id</th>
                                                        <th>Customer</th>
                                                        <th>Created</th>
                                                        <th>Items</th>
                                                        <th>Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                <?php
                                                $count = 1;
                                                foreach($orders as $key=>$order) {
                                                    
                                                ?>
                                                    <tr>
                                                        <td><?=$count;?></td>
                                                        <td><?=$order->order_id;?></td>
                                                        <td><?=$order->cust_name;?></td>
                                                        <td><?=$order->order_created;?></td>
                                                        <td><?=$order->quantity;?></td>
                                                        <td><?=$order->amount;?></td>
                                                        
                                                    </tr>
                                                <?php $count++; } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                    </div>
                               </div>
                  
        <!--============================================================-->
                                <!-- End Body Left  -->
        <!--============================================================-->
        
        
                        </div> 
                        
                        
                </section>      
                </section>      
               
                
<script type="text/javascript">
    $(document).ready(function() {
      /*
       * Insert a 'details' column to the table
       */
      var nCloneTh = document.createElement('th');
      var nCloneTd = document.createElement('td');
    //   nCloneTd.innerHTML = '<img src="lib/advanced-datatable/images/details_open.png">';
    //   nCloneTd.className = "center";
      nCloneTd.className = "hideMe";
      nCloneTh.className = "hideMe";

      $('#hidden-table-info thead tr').each(function() {
        this.insertBefore(nCloneTh, this.childNodes[0]);
      });

      $('#hidden-table-info tbody tr').each(function() {
        this.insertBefore(nCloneTd.cloneNode(true), this.childNodes[0]);
      });

      /*
       * Initialse DataTables, with no sorting on the 'details' column
       */
      var oTable = $('#hidden-table-info').dataTable({
        "bFilter" : false,               
        "bLengthChange": false,
        "searching": false,
        "aoColumnDefs": [{
          "bSortable": false,
          "aTargets": [0]
        }],
        "aaSorting": [
          [1, 'asc']
        ]
      });

    });
  </script>
