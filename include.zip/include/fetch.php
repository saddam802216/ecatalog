<?PHP  

require_once('include.php');

class Fetch {

    public static function getProjectSale($filter = false) {
        
        $filterData = $_POST;
        if($filterData) {
            $where = '';
            
            if(isset($filterData['filter_keywords']) && !empty($filterData['filter_keywords'])) {
                $where .= " AND pro.project_title LIKE '%".$filterData['filter_keywords']."%' OR reserve.reserve_title LIKE '%".$filterData['filter_keywords']."%'";
            }

            if(isset($filterData['filter_state']) && !empty($filterData['filter_state'])) {
                $where .= " AND psi.state='".$filterData['filter_state']."'";
            }
            if(isset($filterData['filter_city']) && !empty($filterData['filter_city'])) {
                $where .= " AND psi.city='".$filterData['filter_city']."'";
            }
            if(isset($filterData['filter_project']) && !empty($filterData['filter_project'])) {
                $where .= " AND psi.project_title='".$filterData['filter_project']."'";
            }
            if(isset($filterData['filter_facing']) && !empty($filterData['filter_facing'])) {
                // $where .= " AND psi.city='".$filterData['filter_facing']."'";
            }
            if(isset($filterData['listing_type']) && !empty($filterData['listing_type'])) {
                // $where .= " AND psi.city='".$filterData['listing_type']."'";
            }
            if(isset($filterData['filter_road_name']) && !empty($filterData['filter_road_name'])) {
                $where .= " AND psi.road_name='".$filterData['filter_road_name']."'";
            }
            if(isset($filterData['filter_reserve']) && !empty($filterData['filter_reserve'])) {
                $where .= " AND psi.reserve='".$filterData['filter_reserve']."'";
            }
            if(isset($filterData['filter_category']) && !empty($filterData['filter_category'])) {
                // $where .= " AND psi.city='".$filterData['filter_category']."'";
            }
        }
    
        require('database.php');
        $data = array();
        if(isset($where) && !empty($where)) {
            $where = ' WHERE ' . $where;
        }
        if($filter) {
            //$query = "SELECT psi.*, ps_img.*, pro.project_title AS project_title_name, reserve.reserve_title FROM `tbl_projectsaleinfo` as psi LEFT JOIN `tbl_projectsaleimage` as ps_img ON psi.property_id=ps_img.property_id LEFT JOIN `projects` AS pro ON psi.project_title=pro.project_id LEFT JOIN `reserve` AS reserve ON psi.reserve=reserve.reserve_id WHERE ps_img.file_type='IMAGE' AND ps_img.file_cover='1' ";         	
        }else {
            $query = "SELECT psi.*, pro.project_title AS project_title_name, reserve.reserve_title FROM `tbl_projectsaleinfo` as psi LEFT JOIN `projects` AS pro ON psi.project_title=pro.project_id LEFT JOIN `reserve` ON psi.reserve=reserve.reserve_id".$where." ORDER BY psi.property_id DESC"; 
        }
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
        }
        
        // Add cover photo 
        
        for($i=0; $i<count($data); $i++) {
            $query = "SELECT file_name FROM `tbl_projectsaleimage` WHERE property_id='".$data[$i]->property_id."' AND file_cover='1'";
            $result = $con->query($query);
            if($result->num_rows > 0){
                while($file = $result->fetch_object()) {
                    $data[$i]->file_name = $file->file_name;			 
                }
            }else{
                $data[$i]->file_name = '';
            }
        }
            
        // prx($data);
            return $data;
        }
        return $data;
    }

    public static function getProjectSaleByID($id = false) {
        require('database.php');
        $data = null;
        if($id) {
            // Get projectsale info
            $query = "SELECT pi.*, projects.project_title AS project_title_name, prn.road_name AS road_name_title, state.state_title, city.city_title, tenures.tenure_title, reserve.reserve_title, commission.commission_title FROM `tbl_projectsaleinfo` AS pi LEFT JOIN `projects` ON pi.project_title=projects.project_id LEFT JOIN `project_road_name` AS prn ON pi.road_name=prn.project_road_id LEFT JOIN `state` ON pi.state=state.state_id LEFT JOIN `city` ON pi.city=city.city_id LEFT JOIN `tenures` ON pi.tenure=tenures.tenure_id LEFT JOIN `reserve` ON pi.reserve=reserve.reserve_id LEFT JOIN `commission` ON pi.commission=commission.commission_id WHERE pi.property_id='".$id."'"; 
            $result = $con->query($query);
            
            if($result->num_rows > 0){
                $data = $result->fetch_object();
            }

            // Get Project Sale Image 
            if($data) {
                $projectSaleImage = array();
                $query = "SELECT * FROM `tbl_projectsaleimage` WHERE property_id='".$id."' AND file_type='IMAGE'"; 
                $result = $con->query($query);
                if($result->num_rows > 0){
                    while($res = $result->fetch_object()) {
                        $projectSaleImage[] = $res;			 
                    }
                }
                // Push tbl_projectsaleimage into data
                
                $data->projectSaleImage = $projectSaleImage;

                // Add YouTube Video
                $projectSaleYouTube = ''; 
                $query = "SELECT * FROM `tbl_projectsaleimage` WHERE property_id='".$id."' AND file_type='VIDEO'"; 
                $result = $con->query($query);
                if($result->num_rows > 0){
                    while($res = $result->fetch_object()) {
                        $projectSaleYouTube = $res;			 
                    }
                }

                $data->projectSaleYouTube = $projectSaleYouTube;
                
                
            }else {
                return $data;
            }

            // Get Project Sale Unit Info
            $unitInfo = array();
            $query = "SELECT ui.*, facing.facing_title, types.type_title, category.category_title, concepts.concept_title FROM `tbl_projectsalesunitinfo` AS ui LEFT JOIN `facing` ON ui.facing=facing.facing_id LEFT JOIN `types` ON ui.type=types.type_id LEFT JOIN `category` ON ui.category=category.category_id LEFT JOIN `concepts` ON ui.concept=concepts.concept_id WHERE ui.property_id='".$id."'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                while($res = $result->fetch_object()) {
                    $unitInfo[] = $res;			 
                }
            }
            
            if($unitInfo) {
                // Add unit info images into unitinfo
                for ($i = 0; $i < count($unitInfo); $i++ ) {
                    $unitInfoImages = array();
                    $id = $unitInfo[$i]->unit_id;
                    $query = "SELECT * FROM `tbl_projectsalesunitimage` WHERE unit_id='".$id."' AND file_type='IMAGE'"; 
                    $result = $con->query($query);
                    if($result->num_rows > 0){
                        while($res = $result->fetch_object()) {
                            $unitInfoImages[] = $res;			 
                        }
                    }
                    // Push tbl_projectsaleunitinfoimage into data
                    
                    $unitInfo[$i]->unitInfoImages = $unitInfoImages;

                    // Add YouTube Video
                    $projectSaleUnitYouTube = ''; 
                    $query = "SELECT * FROM `tbl_projectsalesunitimage` WHERE unit_id='".$id."' AND file_type='VIDEO'"; 
                    $result = $con->query($query);
                    if($result->num_rows > 0){
                        while($res = $result->fetch_object()) {
                            $projectSaleUnitYouTube = $res;			 
                        }
                    }

                    $unitInfo[$i]->projectSaleUnitYouTube = $projectSaleUnitYouTube;

                    // Log info
                    // $query = "SELECT MAX(log_id) AS log_id, date, remarks, user_id, pno, layout_id, project_id FROM `tbl_unitlogs` WHERE layout_id='".$id."' GROUP BY pno"; 
                    // $query = "SELECT a.MAX(log_id) AS log_id, (SELECT b.date, b.remarks, b.user_id, b.pno, b.layout_id, b.project_id FROM `tbl_unitlogs` AS b WHERE b.log_id=a.MAX(log_id) ) FROM `tbl_unitlogs` AS a WHERE a.layout_id='".$id."' GROUP BY a.pno"; 
                    $query = "SELECT MAX(log_id) AS log_id FROM `tbl_unitlogs` WHERE layout_id='".$id."' GROUP BY pno";
                    $result = $con->query($query);
                    $logsID = array();
                    $logs = array();
                    if($result->num_rows > 0){
                        while($res = $result->fetch_row()) {
                            $logsID[] = $res;			 
                        }
                    }
                    $logIdArray = array();
                    foreach ($logsID as $val) {
                        $logIdArray[] = $val[0];
                    }
                    if(!empty($logIdArray)) {
                        $logids = implode(',', $logIdArray);
                        $query = "SELECT * FROM `tbl_unitlogs` WHERE log_id IN (".$logids.")";
                        $result = $con->query($query);
                        if($result->num_rows > 0){
                            while($res = $result->fetch_object()) {
                                $logs[] = $res;			 
                            }
                        }
                    }
                    
                    $unitInfo[$i]->logInfo = $logs;    
                    
                }
            }
            
            $data->unitInfo = $unitInfo;
            
            return $data;
            // prx($data);

        }
    }

    public static function getState() {
        require('database.php');
        $data = array();
        $query = "SELECT state_id, state_title FROM `state`";
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
            return $data;
        }
        return $data;
    }

    public static function getCity() {
        require('database.php');
        $data = array();
        $query = "SELECT city_id, city_title FROM `city`";
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
            return $data;
        }
        return $data;
    }

    public static function getDataByTableName($table = false) {

        require('database.php');
        $data = array();
        if($table) {
            $query = "SELECT * FROM `".$table."`";
            $result = $con->query($query);
            if($result->num_rows > 0){
                while($admin = $result->fetch_object()) {
                    $data[] = $admin;			 
                }
                return $data;
            }
        }
        return $data;
    }

}

?>