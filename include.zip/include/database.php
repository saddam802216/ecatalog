<?php

    // define MySQL database connection
  	// define('DB_SERVER', 'localhost'); 
  	// define('DB_SERVER_USERNAME', 'vikprope_prop');
  	// define('DB_SERVER_PASSWORD', 'sja$(%*bER42e3');
    // define('DB_DATABASE', 'vikprope_prop');

    // define('DB_SERVER', 'localhost'); 
  	// define('DB_SERVER_USERNAME', 'root');
  	// define('DB_SERVER_PASSWORD', '');
    // define('DB_DATABASE', 'vikprope_prop');
      
	$con = mysqli_connect('localhost','root','');
	if (!$con) {
		die('Could not connect: ' . mysqli_error());
	}
	mysqli_select_db($con, 'ecatalog') or die('Could not select database');
	
	
	
?>
