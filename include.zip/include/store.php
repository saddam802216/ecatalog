<?php
require_once('include.php');

$data = $_POST;
session_start();
// prx($data);

$isLogout = ( isset($_GET['task']) && $_GET['task']=='logout' ) ? $_GET['task'] : '';
if($isLogout) {
    $user_type = isset($_SESSION['user']['user_type'])?$_SESSION['user']['user_type'].'/':'';
    session_destroy();
    header('Location: '.BASE_URL.$user_type.'index.php');
}

if(isset($data['login'])) {
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';

    $email = $data['email'];
    $password = md5($data['password']);
    $user_type = '';
    if(isset($data['user_type'])) {
        $user_type = $data['user_type'];
    }
    if($user_type=='admin') {
        $tbl = 'tbl_admin';
        $emailField = 'admin_email';
        $passwordField = 'admin_password';
    }elseif($user_type=='customer') {
        $tbl = 'tbl_customers';
        $emailField = 'cust_email';
        $passwordField = 'cust_password';
    }else{
        $tbl = 'tbl_customers';
        $emailField = 'cust_email';
        $passwordField = 'cust_password';
    }
    $sql = "SELECT * FROM ".$tbl." WHERE ".$emailField."='".$email."'";
    $result = $con->query($sql);
    
	if($result->num_rows > 0){
        $sql = "SELECT * FROM ".$tbl." WHERE ".$emailField."='".$email."'";
        
        $result = $con->query($sql);
        if($result->num_rows > 0){
            $sql = "SELECT * FROM ".$tbl." WHERE ".$emailField."='".$email."' AND ".$passwordField."='".$password."'";
            $result = $con->query($sql);
            while($user = $result->fetch_assoc()) {
                session_start();
                $_SESSION['user'] = $user;			 
                $_SESSION['user']['user_type'] = $user_type;			 
            }
            if(isset($data['remember']) && !empty($data['remember'])) {
                $hour = time() + 3600 * 24 * 30;
                setcookie('email', $email, $hour);
                setcookie('password', $password, $hour);
                setcookie('remember_me', '1', $hour);
            }
            // print_r($user_type.BASE_URL.'index.php'); die(__FILE__);
            if($user_type=='admin') {
                header('Location: '.BASE_URL.'admin/index.php');
            }elseif($user_type=='customer') {
                header('Location: '.BASE_URL.'customer/index.php');
            }else {
                header('Location: '.BASE_URL.'customer/index.php');
            }
                
            exit;
        }else{
            $obj->status = false;
            $obj->message = "Entered wrong password!";
            $_SESSION['login'] = $obj;
            if($user_type=='admin') {
                header('Location: '.BASE_URL.'admin/index.php');
            }elseif($user_type=='customer') {
                header('Location: '.BASE_URL.'customer/index.php');
            }
            exit;
        }
	}else{
        $obj->status = false;
        $obj->message = "User not registerd, Please register first!";
        $_SESSION['login'] = $obj;
        
        if($user_type=='admin') {
            header('Location: '.BASE_URL.'admin/index.php');
        }elseif($user_type=='customer') {
            header('Location: '.BASE_URL.'customer/index.php');
        }
        
        exit;
	}
}

// Customer registration

if(isset($data['registration'])) {
    
    $cust_name = $data['cust_name'];
    $cust_email = $data['cust_email'];
    $cust_password = md5($data['cust_password']);
    $custgroup_id = '';
    $company_id = '';
    $query = "INSERT INTO `tbl_customers`(`cust_id`, `cust_name`, `cust_email`, `cust_password`, `custgroup_id`, `company_id`) VALUES ('','".$cust_name."','".$cust_email."','".$cust_password."','".$custgroup_id."','".$company_id."')";

    if(!$con->query($query)) {
        echo("Error description: " . $con->error);
    }
    header('Location: '.BASE_URL.'customer/index.php');
    exit;
}

if(isset($data['submit_category'])) {
    $category_name = Helper::clean_string($data['category_name']);
    $parent_id = $data['parent_id'];
    $category_id = $data['category_id'];
    $company_id = Helper::getCompanyId();
    
    if(!empty($category_id)) {
        $query = "UPDATE `tbl_categories` SET `category_name`='".$category_name."', `parent_id`='".$parent_id."' WHERE category_id='".$category_id."'";
    }else{
        $query = "INSERT INTO `tbl_categories` (category_id, category_name, parent_id, company_id) VALUES ('', '".$category_name."', '".$parent_id."', '".$company_id."') ";
    }
    if(!$con->query($query)) {
        echo("Error description: " . $con->error);
    }
    header('Location: '.BASE_URL.'admin/index.php?page=category');
    exit;
}

if(isset($data['submit_product'])) {
    // prx($_FILES);
    
    $product_id = $data['product_id'];
    $product_name = $data['product_name'];
    $product_description = $data['product_description'];
    $product_quantity = $data['product_quantity'];
    $category_id = implode(',', $data['category_id']);
    $price = $data['price'];
    $customer_group = $data['customer_group'];
    $company_id = Helper::getCompanyId();

    // Insert or update product table
    if(empty($product_id)) {
        $query = "INSERT INTO tbl__products (`product_id`, `product_name`, `product_description`, `product_quantity`, `category_id`, `company_id`) VALUES('', '".$product_name."', '".$product_description."', '".$product_quantity."', '".$category_id."', '".$company_id."')";
    }else {
        $query = "UPDATE `tbl__products` SET `product_name`='".$product_name."',`product_description`='".$product_description."',`product_quantity`='".$product_quantity."',`category_id`='".$category_id."' WHERE product_id='".$product_id."'";
    }
    
    if(!$con->query($query)) {
        echo("Error description: " . $con->error);
        return false;
    }
    $product_id = empty($product_id) ? $con->insert_id : $product_id;

    // Insert or update product price table

    // Remove Previous Product price
    $query = "DELETE FROM `tbl_productprices` WHERE product_id='".$product_id."'";
    if(!$con->query($query)) {
        echo("Error description: " . $con->error);
    }

    // Add Product price
    for($i=0; $i<count($price); $i++) {
        if(empty($price[$i])) {
            continue;
        }
        if(empty($customer_group[$i])) {
            $custgroup_id = new stdClass();
            $defaultGroup = Helper::defaultCustomerGroup();
            $customer_group[$i] = $defaultGroup->custgroup_id;
        }
        $query = "INSERT INTO `tbl_productprices`(`price_id`, `product_price`, `product_id`, `custgroup_id`) VALUES ('', '".$price[$i]."', '".$product_id."', '".$customer_group[$i]."')";
        if(!$con->query($query)) {
            echo("Error description: " . $con->error);
        }
    }
    // Add Product Image
    
    // Store Uploaded Photoes in table
    $file = $_FILES;
    $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
    $videoExts = array("webm", "mp4", "ogv");
    for( $i=0; $i<count($file["photo_upload"]["name"]); $i++ ) {
        $extension = explode(".", $file["photo_upload"]["name"][$i]);
        $extension = end($extension);
        $src = $file['photo_upload']['tmp_name'][$i];
        
        if ( in_array($extension, $allowedExts) ) {
    
            $time = time();
            $rand=rand(10000,999999999);
            $encname=$time.$rand;
            $imgName=$encname.'.'.$extension;
            $imgPath=ROOT_DIR.UPLOAD_IMAGE_PATH.$imgName;
            if(move_uploaded_file($src, $imgPath)) {
            
                $file_id = null;
                $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                $file_name = $imgName;
                $file_cover = ( isset($data['cover_photo']) && ($data['cover_photo']==$file["photo_upload"]["name"][$i]) ) ? 1 : 0;
               
                $query = "INSERT INTO `tbl_productimages` (file_id, file_type, file_name, file_cover, product_id) VALUES ('', '".$file_type."', '".$file_name."', '".$file_cover."', '".$product_id."')";

                if (!$con->query($query)) {
                    continue;
                } 
            }
            
        }
    }
    // prx($con->error);
    header('Location: '.BASE_URL.'admin/index.php?page=products');
    exit;
}

if(isset($data['submit_customer'])) {
    
    $cust_name = $data['cust_name'];
    $cust_email = $data['cust_email'];
    $cust_password = md5($data['cust_password']);
    $custgroup_id = $data['custgroup_id'];
    $company_id = Helper::getCompanyId();
    $customer_id = $data['customer_id'];
    
    if(!empty($customer_id)) {
        $query = "UPDATE `tbl_customers` SET `cust_name`='".$cust_name."', `cust_email`='".$cust_email."', `custgroup_id`='".$custgroup_id."', `company_id`='".$company_id."' WHERE cust_id='".$customer_id."'";
    }else{
        $query = "INSERT INTO `tbl_customers`(`cust_id`, `cust_name`, `cust_email`, `cust_password`, `custgroup_id`, `company_id`) VALUES ('','".$cust_name."','".$cust_email."','".$cust_password."','".$custgroup_id."','".$company_id."')";
    }
    if(!$con->query($query)) {
        echo("Error description: " . $con->error);
    }
    header('Location: '.BASE_URL.'admin/index.php?page=customers');
    exit;
}

if(isset($data['submit_checkout'])) {
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';
    $company_id = Helper::getCompanyId();
    $cust_id = Helper::getLoginUser();
    $created = date('Y-m-d');
    $order_ref = '';
    $discount = 0;
    
    // create order

    $query = "INSERT INTO `tbl_orders`(`order_id`, `order_ref`, `order_created`, `company_id`, `cust_id`) VALUES ('','".$order_ref."','".$created."','".$company_id."','".$cust_id."')";
    if(!$con->query($query)) {
        return false;
    }
    $order_id = $con->insert_id;
    
    // Create order items
    if($order_id) {
        for( $i=0; $i<count($data['product_id']); $i++ ) {
            $quantity = $data['quantity'][$i];
            $product_id = $data['product_id'][$i];
            $product_name = $data['product_name'][$i];
            $product_price = $data['product_price'][$i];
            
            $query = "INSERT INTO `tbl_orders_item`(`item_id`, `item_name`, `item_price`, `item_quantity`, `item_discount`, `order_id`, `product_id`) VALUES ('','".$product_name."','".$product_price."','".$quantity."','".$discount."','".$order_id."','".$product_id."')";
            if(!$con->query($query)) {
                continue;
            }
        }
    }

    // Remove Cart Items
    $query = "DELETE FROM `tbl_cart` WHERE cust_id='".$cust_id."'";
    if(!$con->query($query)) {
        return false;
    }

    header('Location: '.BASE_URL.'customer/index.php?page=products');

}

if(isset($data['submit_projectsale'])) {
    
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';
    // Store data in table
    $property_id = null;
    $listing_type = 'Project Sale';
    $project_title = $data['project_title'];
    $road_name = $data['road_name'];
    $state = $data['state'];
    $layout = $data['layout'];
    $city = $data['city'];
    $tenure = $data['tenure'];
    $reserve = $data['reserve'];
    $commission = $data['commission'];
    $poster_banner = $data['poster_banner'];
    $ads_date = $data['ads_date'];
    $remarks = $data['remarks'];
    $listing_date = $data['listing_date'];
    $listing_by = $data['listing_by'];
    $bringin_by = $data['bringin_by'];

    $file = $_FILES;
    //$photo_uplaod = ( isset($file['photo_upload']) && !empty($file['photo_upload']) ) ? 1 : 0;
// 
    $query = "INSERT INTO `tbl_projectsaleinfo` (property_id, listing_type, project_title, road_name, state, layout, city, tenure, reserve, commission, poster_banner, ads_date, remarks, listing_date, listing_by, bringin_by) VALUES ('', '".$listing_type."', '".$project_title."', '".$road_name."', '".$state."', '".$layout."', '".$city."', '".$tenure."', '".$reserve."', '".$commission."', '".$poster_banner."', '".$ads_date."', '".$remarks."', '".$listing_date."', '".$listing_by."', '".$bringin_by."')";
    $res = $con->query($query);
    
    if ($res === TRUE) {
        $property_id = $con->insert_id;
        if(!empty($property_id)) {
            // Store Uploaded Photoes in table
            $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
            $videoExts = array("webm", "mp4", "ogv");
            for( $i=0; $i<count($file["photo_upload"]["name"]); $i++ ) {
                $extension = explode(".", $file["photo_upload"]["name"][$i]);
                $extension = end($extension);
                $src = $_FILES['photo_upload']['tmp_name'][$i];
                
                if ( in_array($extension, $allowedExts) ) {
            
                    $time = time();
                    $rand=rand(10000,999999999);
                    $encname=$time.$rand;
                    $imgName=$encname.'.'.$extension;
                    $imgPath=ROOT_DIR.UPLOAD_IMAGE_PATH.$imgName;
                    if(move_uploaded_file($src, $imgPath)) {
                    
                        $file_id = null;
                        $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                        $file_name = $imgName;
                        $file_cover = ( isset($data['cover_photo']) && ($data['cover_photo']==$file["photo_upload"]["name"][$i]) ) ? 1 : 0;
                        // $file_cover = '';
                        $property_id = $property_id;
                        $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";
    
                        if (!$con->query($query)) {
                            continue;
                        } 
                    }
                }
            }

            // Add YouTube video 
            $youtube_video = $data['sale_youtube_video'];
            if($youtube_video) {
                $file_id = '';
                $file_type = 'VIDEO';
                $file_name = $youtube_video;
                $file_cover = 0;
                $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";
                $con->query($query);
            }


            // Store data in unitinfo table

            // for($i=0; $i<$layout; $i++) {
                if(false) {
                $unit_id = '';
                $property_id = $property_id;
                $pno = $data['pno'][$i];
                // if(empty($pno))
                // continue;
                $facing = $data['facing'][$i];
                $land_area = $data['land_area'][$i];
                $built_up = $data['built_up'][$i];
                $category = $data['category'][$i];
                $type = $data['type'][$i];
                $concept = $data['concept'][$i];
                $room = $data['room'][$i];
                $bathroom = $data['bathroom'][$i];
                $flooring = $data['flooring'][$i];
                $snp_price = $data['s&p_price'][$i];
                $promotion_price = $data['promotion_price'][$i];
                
                // $unitinfo_photo_upload = ( isset($file['unitinfo_photo_upload']['name'][$i]) && !empty($file['unitinfo_photo_upload']['name'][$i]) ) ? 1 : 0;
                // $unitinfo_video_link = $data['unitinfo_video_link'][$i];

                $query = "INSERT INTO `tbl_projectsalesunitinfo` (unit_id, property_id, pno, facing, land_area, built_up, category, type, concept, room, bathroom, flooring, snp_price, promotion_price) VALUES ('".$unit_id."', '".$property_id."', '".$pno."', '".$facing."', '".$land_area."', '".$built_up."', '".$category."', '".$type."', '".$concept."', '".$room."', '".$bathroom."', '".$flooring."', '".$snp_price."', '".$promotion_price."')";
                $res = $con->query($query);
                
                if ($res === TRUE) {
                    $unit_id = $con->insert_id;
                    if(!empty($unit_id)) {
                        // Store Uploaded Photoes in table
                        $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
                        $videoExts = array("webm", "mp4", "ogv");
                        for( $j=0; $j<count($file["unitinfo_photo_upload"]["name"][$i]); $j++ ) {
                            $extension = explode(".", $file["unitinfo_photo_upload"]["name"][$i][$j]);
                            $extension = end($extension);
                            $src = $_FILES['unitinfo_photo_upload']['tmp_name'][$i][$j];
                            
                            if ( in_array($extension, $allowedExts) ) {
                        
                                $time = time();
                                $rand=rand(10000,999999999);
                                $encname=$time.$rand;
                                $imgName=$encname.'.'.$extension;
                                $imgPath=ROOT_DIR.UPLOAD_UNITINFO_IMAGE_PATH.$imgName;
                                if(move_uploaded_file($src, $imgPath)) {
                                
                                    $file_id = '';
                                    $file_type = $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                                    $file_name = $imgName;
                                    $file_cover = ( isset($data['unit_info_cover_photo'][$i]) && ($data['unit_info_cover_photo'][$i]==$file["unitinfo_photo_upload"]["name"][$i][$j]) ) ? 1 : 0;
                                    $unit_id = $unit_id;
                                    $query = "INSERT INTO `tbl_projectsalesunitimage` (file_id, file_type, file_name, file_cover, unit_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$unit_id."')";
                
                                    if (!$con->query($query)) {
                                        continue;
                                    } 
                                }
                            }
                        }
                    }
                }
            }
        }
        header('Location: '.BASE_URL.'index.php?page=projectsale_edit&id='.$property_id.'&layout=1');
        exit;
    }
    header('Location: '.BASE_URL.'index.php?page=projectsale');
}
if(isset($data['submit_save_password'])) {
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';
    
    if($data['submit_save_password']) {
        $password = $data['password'];
        $currentDate = date('Y-m-d');
        $userid = Helper::getUserId();
        
        $query = "UPDATE `users` SET  `password`='".$password."', `modified`='".$currentDate."' WHERE id='".$userid."'";
        
        if ($conn->query($query) === TRUE) {
            header('Location: login.php');
            exit;
        }
    }

    $obj->status = false;
    $obj->message = 'File not uploaded!';
    header('Location: password.php');
    exit;

}


?>