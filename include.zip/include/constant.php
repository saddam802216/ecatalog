<?php

    define('DIR_INCLUDE_PATH', 'include/');	
    define('DIR_ADMIN_PATH', 'admin/');	
    define('DIR_CUSTOMER_PATH', 'customer/');	
    define('BASE_URL', 'http://localhost/ecatalog/');
    define('ROOT_DIR', 'C:/xampp/htdocs/ecatalog/');
    define('UPLOAD_IMAGE_PATH', 'upload/product_images/');
    define('UPLOAD_UNITINFO_IMAGE_PATH', 'upload/unit_info_image/');
    define('SITE_IMAGE_PATH', 'include/assets/img/');
    	
    
    
?>