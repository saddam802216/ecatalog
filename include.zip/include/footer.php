<!--footer start-->
<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Viks Properties</strong>. All Rights Reserved
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
          Created by <a href="https://www.operion.com.my">Operion Ecommerce & Software Sdn Bhd</a>
        </div>
        <a href="inbox.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  
  <script src="../include/assets/lib/bootstrap/js/bootstrap.min.js"></script>
  <!-- <script type="text/javascript" language="javascript" src="../include/assets/lib/advanced-datatable/js/jquery.js"></script> -->
  <script class="include" type="text/javascript" src="../include/assets/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../include/assets/lib/jquery.scrollTo.min.js"></script>
  <script src="../include/assets/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script type="text/javascript" language="javascript" src="../include/assets/lib/advanced-datatable/js/jquery.dataTables.js"></script>
  <script type="text/javascript" src="../include/assets/lib/advanced-datatable/js/DT_bootstrap.js"></script>
  <!--<script src="../include/assets/js/script1.0.1.js"></script>-->
  <!--common script for all pages-->
  <script src="../include/assets/lib/common-scripts.js"></script>
  <!--script for this page-->
  
  
</body>

</html>