<?php

require_once('include.php');

$data = $_POST;

// Get Caterogy By caterory_id

if($data['task']=='updateCategory') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Category not Found';
    $obj->category = '';

    $category_id = $data['category_id'];
    if($category_id > 0) {
        $query = "SELECT * FROM `tbl_categories` WHERE category_id='".$category_id."'";
        $result = $con->query($query);
        if($result->num_rows > 0){
            $category = $result->fetch_object();
            $obj->success = true;
            $obj->message = 'Category Found';
            $obj->category = $category;
        }    
    }
    exit(json_encode($obj));
}

// Remove Category 

if($data['task']=='removeCategory') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Category not Remove';

    $category_id = $data['category_id'];
    if($category_id > 0) {
        $query = "DELETE FROM `tbl_categories` WHERE category_id='".$category_id."'";
        if($con->query($query)){
            $obj->success = true;
            $obj->message = 'Category Removed';
        }    
    }
    exit(json_encode($obj));
}

// Remove Product 

if($data['task']=='removeProduct') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Product not Remove';

    $product_id = $data['product_id'];
    if($product_id > 0) {
        // Remove Product
        $query = "DELETE FROM `tbl__products` WHERE product_id='".$product_id."'";
        if($con->query($query)){
            $obj->success = true;
            $obj->message = 'Product Removed';
        }    

        // Remove Product Price

        $query = "DELETE FROM `tbl_productprices` WHERE product_id='".$product_id."'";
        if($con->query($query)){
            $obj->success = true;
            $obj->message = 'Product Removed';
        } 

        // Remove Product Images

        $query = "DELETE FROM `tbl_productimages` WHERE product_id='".$product_id."'";
        if($con->query($query)){
            $obj->success = true;
            $obj->message = 'Product Removed';
        } 
    }
    exit(json_encode($obj));
}

// Remove Customer 

if($data['task']=='removeCustomer') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Customer not Remove';

    $cust_id = $data['cust_id'];
    if($cust_id > 0) {
        $query = "DELETE FROM `tbl_customers` WHERE cust_id='".$cust_id."'";
        if($con->query($query)){
            $obj->success = true;
            $obj->message = 'Customer Removed';
        }    
    }
    exit(json_encode($obj));
}

// Remove CartItem 

if($data['task']=='removeCartItem') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Item not Remove';
    $product_id = $data['product_id'];
    $cust_id = Helper::getLoginUser();

    if($product_id > 0) {
        $query = "DELETE FROM `tbl_cart` WHERE product_id='".$product_id."' AND cust_id='".$cust_id."'";
        if($con->query($query)){
            $obj->success = true;
            $obj->message = 'Item Removed Successfully';
        }    
    }
    exit(json_encode($obj));
}


//  View Product Detail on Modal Body

if($data['task']=='viewProductModalData') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Product not Found';
    $obj->html = '';
    $html = '';
    if($data['product_id']) {
        $product = Helper::getProductDetail($data['product_id']);
        $categoryTree = helper::getCategoryTree();
        // prx($product);
        $html .= '<div class="col-sm-12">
        <table class="table table-borderless view-table">
            <tbody>
                <tr>
                    <td class="td-w-25">Product Name</td>
                    <td>:</td>
                    <td class="td-w-60">'.$product->product_name.'</td>
                </tr>
                <tr>
                    <td class="">Product Quantity</td>
                    <td>:</td>
                    <td class="">'.$product->product_quantity.'</td>
                </tr>
                <tr>
                    <td class="">Product Description</td>
                    <td>:</td>
                    <td class="">'.$product->product_description.'</td>
                </tr>
                <tr>
                    <td class="">Category</td>
                    <td>:</td><td>';
                    //$html .= '<td class="">'.$product->sub_category_name.'</td>
                    
                    $categoryArray = explode(',', $product->category_id);
                    foreach($categoryTree as $key=>$val) {
                        if(in_array($val->category_id, $categoryArray)){
                        $html .= '<div class="row"><div class="col-sm-4 main-category">'.$val->category_name.'</div></div>';
                        }
                        foreach($val->child_category as $key1=>$val1) {
                            if(in_array($val1->category_id, $categoryArray)){
                            $html .= '<div class="row sub-category-style"><div class="col-sm-4 sub-category">'.$val1->category_name.'</div>';
                            }

                        }
                    }
                $html .= '</td></tr>';
                $priceTxt = 'Price';    
                for($i=0; $i<4; $i++) {
                    $priceGroup = new stdClass();
                    $priceGroup->custgroup_id = 0;
                    $priceGroup->product_price = 0;
                    $priceGroup->custgroup_name = 0;
                    if(isset($product->prices[$i])){
                        $priceGroup = $product->prices[$i];
                    }

                    $html .= '<tr>
                            <td class="">'.$priceTxt.'</td>
                            <td>:</td>
                            <td class="">'.$priceGroup->custgroup_name.'</td>
                            <td class="">'.$priceGroup->product_price.'</td>
                            <td style="padding: 0px 50px;"> &nbsp; </td>
                        </tr>';
                        $priceTxt = '';
                }

            $html .= '</tbody>
                    </table> 
                </div>';

            $html .= '<div class="col-md-12">
            <div class="main-container">
            <div id="unitCarousel" class="carousel slide" data-interval="false"> <div class="carousel-inner">';
            
            $isCoverPhoto = false;
            for($j=0; $j<count($product->images); $j++) {
                $active = ($product->images[$j]->file_cover)?' active':'';
                if($active) {
                    $isCoverPhoto = true;
                }
                
            $html .= '<div class="item '.$active.'">
                    <img src="'.BASE_URL.UPLOAD_IMAGE_PATH.$product->images[$j]->file_name.'" alt="Los Angeles" style="width:100%; height:260px">
                </div>';
                        
            } 
                
            if(!$isCoverPhoto) {

            $html .= '<div class="item active">
                    <img src="'.BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png'.'" alt="Los Angeles" style="width:100%; height:260px">
                </div>';
                 
            }
                

            $html .= '</div>

            <a class="left carousel-control" href="#unitCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#unitCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="row" style="margin-top: 10px;">';
            
        for($j=0; $j<count($product->images); $j++) {
            if($product->images[$j]->file_cover) {
                continue;
            }
    
        $html .= '<div class="col-sm-4 col-xs-6" style="padding-top: 10px;">
                <img src="'.BASE_URL.UPLOAD_IMAGE_PATH.$product->images[$j]->file_name.'" alt="Los Angeles" style="width:100%; height:120px">
            </div>';

            }

        $html .= '</div></div></div>';    

            $obj->success = true;
            $obj->message = 'Product Found';    
            $obj->html = $html;
    }
    
    exit(json_encode($obj));
}

// Get Customer By customer_id

if($data['task']=='updateCustomer') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Customer not Found';
    $obj->customer = '';

    $cust_id = $data['customer_id'];
    if($cust_id > 0) {
        $query = "SELECT * FROM `tbl_customers` WHERE cust_id='".$cust_id."'";
        $result = $con->query($query);
        if($result->num_rows > 0){
            $customer = $result->fetch_object();
            $obj->success = true;
            $obj->message = 'Customer Found';
            $obj->customer = $customer;
        }    
    }
    exit(json_encode($obj));
}

if($data['task']=='submit_addtocart') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Cart not store';
    $product_id = $data['product_id'];
    $quantity = $data['quantity'];
    $cust_id = Helper::getLoginUser();

    // Check if already added to cart
    $query = "SELECT * FROM `tbl_cart` WHERE cust_id='".$cust_id."' AND product_id='".$product_id."' ";
    $result = $con->query($query);
    if($result->num_rows > 0) {
        $cartItem = $result->fetch_object();
        $quantity += $cartItem->product_quantity; 
        $query = "UPDATE `tbl_cart` set `product_quantity`='".$quantity."' WHERE cust_id='".$cust_id."' AND product_id='".$product_id."' ";
    }else{
        $query = "INSERT INTO `tbl_cart`(`cart_id`, `product_quantity`, `product_id`, `cust_id`) VALUES ('','".$quantity."', '".$product_id."', '".$cust_id."')";
    }

    if($con->query($query)) {
        $obj->success = true;
        $obj->message = 'Cart Store Successfully';
        $obj->total_quantity = Helper::getCartCount();
    }
    // prx($con->error);
    exit(json_encode($obj));
}

if($data['task']=='updateCartProductQuantity') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Quantity not update';
    $product_id = $data['product_id'];
    $quantity = $data['quantity'];
    $cust_id = Helper::getLoginUser();

    // Check if already added to cart
    $query = "SELECT * FROM `tbl_cart` WHERE cust_id='".$cust_id."' AND product_id='".$product_id."' ";
    $result = $con->query($query);
    if($result->num_rows > 0) {
        $cartItem = $result->fetch_object();
        $query = "UPDATE `tbl_cart` set `product_quantity`='".$quantity."' WHERE cust_id='".$cust_id."' AND product_id='".$product_id."' ";
        
        if($con->query($query)) {
            $obj->success = true;
            $obj->message = 'Quantity Update Successfully';
        }
    }

    // prx($con->error);
    exit(json_encode($obj));
}

// Code to delete

if($data['task']=='getStatusData') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Status not Found';
    $modalBodyHtml = '';
    
    $pno = $data['pno'];
    $layout_id = $data['layout_id'];

    $query = "SELECT * FROM `tbl_unitlogs` WHERE layout_id='".$layout_id."' AND pno='".$pno."' ORDER BY log_id DESC LIMIT 1";
    $result = $con->query($query);
    if($result->num_rows > 0){
        $log = $result->fetch_object();

        $obj->success = true;
        $obj->message = 'Status Found';
        // Get loging User
        $loginUserId = Helper::getLoginUser();
        $loginUser = Helper::getUserById($loginUserId);
        if($log->remarks=='Booking') {
            if($log->user_id==$loginUserId || $loginUser->admin_group=='ADMIN' || $loginUser->admin_group=='SYS_ADMIN') {
                $modalBodyHtml .= '<h5>Would you like to cancel booking this unit?</h5>
                <input type="submit" class="btn btn-primary updateStatusSubmit" value="Cancel Booking">';
                if(isset($log->log_remarks) && !empty($log->log_remarks)) {
                    $modalBodyHtml .= '<h5>Remarks : '.$log->log_remarks.'</h5>';
                }
            }else{
                $bookedUser = Helper::getUserById($log->user_id);
                $bookedUserName = $bookedUser->admin_firstname;
                $modalBodyHtml .= '<h5> This Unit is booked by '.$bookedUserName.'</h5>'; 
                if(isset($log->log_remarks) && !empty($log->log_remarks)) {
                    $modalBodyHtml .= '<h5>Remarks : '.$log->log_remarks.'</h5>';
                }  
            }
        }else{
            $modalBodyHtml .= '<h5>Would you like to booking this unit?</h5>
            <input type="submit" class="btn btn-primary updateStatusSubmit" value="Booking"><p style="padding-top:10px;">Remarks</p><textarea name="log_remarks" id="log_remarks" class="log_remarks"></textarea>';
        }
    }else{
        $modalBodyHtml .= '<h5>Would you like to booking this unit?</h5>
        <input type="submit" class="btn btn-primary updateStatusSubmit" value="Booking"><p style="padding-top:10px;">Remarks</p><textarea name="log_remarks" id="log_remarks" class="log_remarks"></textarea>';
    }

    $obj->modalBody = $modalBodyHtml;
    exit(json_encode($obj));
}

if($data['task']=='updateStatus') {
    // prx($data);
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Status not update';
    $log_id = '';
    $date = date("Y-m-d");
    $remarks = $data['remarks'];
    $user_id = Helper::getLoginUser();
    $pno = $data['pno'];
    $layout_id = $data['layout_id'];
    $project_id = $data['project_id'];
    $log_remarks = $data['log_remarks'];

    $query = "INSERT INTO `tbl_unitlogs` (log_id, date, remarks, user_id, pno, layout_id, project_id, log_remarks) VALUES('".$log_id."', '".$date."', '".$remarks."', '".$user_id."', '".$pno."', '".$layout_id."', '".$project_id."', '".$log_remarks."')";
    if ($con->query($query)) {
        $obj->success = true;
        $obj->message = 'Status update successfully';
        $obj->status = $remarks;
        $obj->date = $date;
        $user = Helper::getUserById($user_id);
        $obj->agent = $user->admin_firstname;
    } 

    // prx($con->error);

    exit(json_encode($obj));
}

if($data['task']=='getUnitLog') {
    
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Log not found';
    $obj->html = '';
    $pno = $data['pno'];
    $layout_id = $data['layout_id'];
    $project_id = $data['project_id'];
    $logs = array();

    $query = "SELECT ul.*, u.admin_firstname AS user_name FROM `tbl_unitlogs` AS ul LEFT JOIN `administrators` AS u on ul.user_id=u.admin_id WHERE project_id='".$project_id."' AND layout_id='".$layout_id."' AND pno='".$pno."' ORDER BY log_id DESC";
    $result = $con->query($query);
    if($result->num_rows > 0){
        while($res = $result->fetch_object()) {
            $logs[] = $res;			 
        }
    }

    if(!empty($logs)) {
        $logHtml = '';
        foreach($logs as $key=>$log) {
            $index = $key+1;
            $logHtml .= '<tr>
            <th scope="row">'.$index.'</th>
            <td>'.$log->date.'</td>
            <td>'.$log->remarks.'</td>
            <td>'.$log->user_name.'</td>
            </tr>'; 
        }
        $obj->html = $logHtml;
        $obj->success = true;
        $obj->message = 'Logs Available'; 
    }else {
        $obj->html = '<tr><td colspan="4"><h5 style="text-align:center"> Log not available </h5></td></tr>';
    }
    // prx($obj);
    exit(json_encode($obj));
}

// Update Sale Info

if($data['task']=='updateSaleInfo') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Data not update';
    $form_data = array();
    parse_str($data['saleFormData'], $form_data);

    $property_id = $form_data['property_id'];
    // $listing_type = 'Project Sale';
    $project_title = $form_data['project_title'];
    $layout = $form_data['layout'];
    $road_name = $form_data['road_name'];
    $state = $form_data['state'];
    $city = $form_data['city'];
    $tenure = $form_data['tenure'];
    $reserve = $form_data['reserve'];
    $commission = $form_data['commission'];
    $poster_banner = $form_data['poster_banner'];
    $ads_date = $form_data['ads_date'];
    $remarks = $form_data['remarks'];
    $listing_date = $form_data['listing_date'];
    $listing_by = $form_data['listing_by'];
    $bringin_by = $form_data['bringin_by'];

    $query = "UPDATE `tbl_projectsaleinfo` SET `project_title`='".$project_title."', `layout`='".$layout."', `road_name`='".$road_name."', `state`='".$state."', `city`='".$city."', `tenure`='".$tenure."', `reserve`='".$reserve."', `commission`='".$commission."', `poster_banner`='".$poster_banner."', `ads_date`='".$ads_date."', `remarks`='".$remarks."', `listing_date`='".$listing_date."', `listing_by`='".$listing_by."', `bringin_by`='".$bringin_by."' WHERE property_id='".$property_id."'";
    if($con->query($query) === TRUE) {
        // Store Uploaded Photoes in table
        $files = $_FILES;
        if($files) {
            $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
            $videoExts = array("webm", "mp4", "ogv");
            for( $i=0; $i<count($files["files"]["name"]); $i++ ) {
                $extension = explode(".", $files["files"]["name"][$i]);
                $extension = end($extension);
                $src = $_FILES['files']['tmp_name'][$i];
                
                if ( in_array($extension, $allowedExts) ) {
            
                    $time = time();
                    $rand=rand(10000,999999999);
                    $encname=$time.$rand;
                    $imgName=$encname.'.'.$extension;
                    $imgPath=ROOT_DIR.UPLOAD_IMAGE_PATH.$imgName;
                    if(move_uploaded_file($src, $imgPath)) {
                    
                        $file_id = '';
                        $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                        $file_name = $imgName;
                        $file_cover = ( isset($form_data['general_info_cover_photo']) && ($form_data['general_info_cover_photo']==$files["files"]["name"][$i]) ) ? 1 : 0;
                        
                        // Remove cover photo on upload new cover photo
                        if($file_cover) {
                            $query1 = "UPDATE `tbl_projectsaleimage` SET `file_cover`='0' WHERE property_id='".$property_id."'";
                            $con->query($query1);
                        }
                        
                        $property_id = $property_id;
                        $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";

                        if (!$con->query($query)) {
                            continue;
                        } 
                    }
                }
            }
        }

        // Add or update YouTube video
        if(isset($form_data['sale_youtube_video']) && !empty($form_data['sale_youtube_video'])) {
            $query = "SELECT * FROM `tbl_projectsaleimage` WHERE property_id='".$property_id."' AND file_type='VIDEO'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                // Update YouTube video
                $query = "UPDATE `tbl_projectsaleimage` SET `file_name`='".$form_data['sale_youtube_video']."' WHERE property_id='".$property_id."' AND file_type='VIDEO'";
            }else {
                // Add YouTube video
                $file_id = '';
                $file_type = 'VIDEO';
                $file_name = $form_data['sale_youtube_video'];
                $file_cover = 0;
                $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";
            }
            $con->query($query);
        }


        $obj->success = true;
        $obj->message = 'Data update successfully';
        $obj->url = BASE_URL.'index.php?page=projectsale_edit&id='.$property_id.'&layout=1';
    }
    exit(json_encode($obj));
}


// Update unit info


if($data['task']=='updateUnitInfo') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Data not update';
    $obj->imageHtml = '';
    $form_data = array();
    parse_str($data['unitInfoFormData'], $form_data);
    
    $unit_id = $form_data['unitInfo_id'];
    $pno = $form_data['pno'];
    $facing = $form_data['facing'];
    $land_area = $form_data['land_area'];
    $built_up = $form_data['built_up'];
    $category = $form_data['category'];
    $type = $form_data['type'];
    $concept = $form_data['concept'];
    $room = $form_data['room'];
    $bathroom = $form_data['bathroom'];
    $flooring = $form_data['flooring'];
    $snp_price = $form_data['s&p_price'];
    $promotion_price = $form_data['promotion_price'];
    // prx($form_data);
    if(!empty($unit_id)) {
        $query = "UPDATE `tbl_projectsalesunitinfo` SET `pno`='".$pno."', `facing`='".$facing."', `land_area`='".$land_area."', `built_up`='".$built_up."', `category`='".$category."', `type`='".$type."', `concept`='".$concept."', `room`='".$room."', `bathroom`='".$bathroom."', `flooring`='".$flooring."', `snp_price`='".$snp_price."', `promotion_price`='".$promotion_price."' WHERE unit_id='".$unit_id."'";
    }else{
        $unit_id = '';
        $property_id = $form_data['property_id'];
        $query = "INSERT INTO `tbl_projectsalesunitinfo` (unit_id, property_id, pno, facing, land_area, built_up, category, type, concept, room, bathroom, flooring, snp_price, promotion_price) VALUES ('".$unit_id."', '".$property_id."', '".$pno."', '".$facing."', '".$land_area."', '".$built_up."', '".$category."', '".$type."', '".$concept."', '".$room."', '".$bathroom."', '".$flooring."', '".$snp_price."', '".$promotion_price."')";
    }
    
    if($con->query($query) === TRUE) {
        // Store Uploaded Photoes in table
        if(empty($unit_id)) {
            $unit_id = $con->insert_id;
        }
        $files = $_FILES;
        if($files) {
            $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
            $videoExts = array("webm", "mp4", "ogv");
            for( $i=0; $i<count($files["files"]["name"]); $i++ ) {
                $extension = explode(".", $files["files"]["name"][$i]);
                $extension = end($extension);
                $src = $_FILES['files']['tmp_name'][$i];
                
                if ( in_array($extension, $allowedExts) ) {
            
                    $time = time();
                    $rand=rand(10000,999999999);
                    $encname=$time.$rand;
                    $imgName=$encname.'.'.$extension;
                    $imgPath=ROOT_DIR.UPLOAD_UNITINFO_IMAGE_PATH.$imgName;
                    if(move_uploaded_file($src, $imgPath)) {
                    
                        $file_id = '';
                        $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                        $file_name = $imgName;
                        $file_cover = ( isset($form_data['unit_info_cover_photo']) && ($form_data['unit_info_cover_photo']==$files["files"]["name"][$i]) ) ? 1 : 0;
                        
                        // Remove cover photo on upload new cover photo
                        if($file_cover) {
                            $query = "UPDATE `tbl_projectsalesunitimage` SET `file_cover`='0' WHERE unit_id='".$unit_id."'";
                            $con->query($query);
                        }
                        
                        $query = "INSERT INTO `tbl_projectsalesunitimage` (file_id, file_type, file_name, file_cover, unit_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$unit_id."')";

                        if (!$con->query($query)) {
                            continue;
                        } 
                    }
                }
            }

            // get unit image 
            $imageHtml = '';
            $query = "SELECT * FROM `tbl_projectsalesunitimage` WHERE unit_id='".$unit_id."' AND file_type='IMAGE'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                while($res = $result->fetch_object()) {
                    $coverPhotoClass = '';
                    $coverPhoto_tooltip = '';
                    if($res->file_cover) {
                        $coverPhotoClass = 'cover-photo';
                        $coverPhoto_tooltip = 'data-toggle="tooltip" title="Cover Photo!"';
                    }
                    $imageHtml .= '<div class="col-sm-3 col-xs-6 image-main '.$coverPhotoClass.'" style="padding-top: 10px;">
                    <a href="javascript::void()" class="removeImage" data-id="'.$res->file_id.'" data-type="unit" '.$coverPhoto_tooltip.'><i class="fa fa-times fa-1x "></i></a>
                    <img src="'.BASE_URL.UPLOAD_UNITINFO_IMAGE_PATH.$res->file_name.'" alt="Los Angeles" style="width:100%; height:60px" class="img-main">
                </div>';			 
                }
            }
            $obj->imageHtml = $imageHtml;
        }

        // Add or update YouTube video
        if(isset($form_data['unit_youtube_video']) && !empty($form_data['unit_youtube_video'])) {
            $query = "SELECT * FROM `tbl_projectsalesunitimage` WHERE unit_id='".$unit_id."' AND file_type='VIDEO'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                // Update YouTube video
                $query = "UPDATE `tbl_projectsalesunitimage` SET `file_name`='".$form_data['unit_youtube_video']."' WHERE unit_id='".$unit_id."' AND file_type='VIDEO'";
            }else {
                // Add YouTube video
                $file_id = '';
                $file_type = 'VIDEO';
                $file_name = $form_data['unit_youtube_video'];
                $file_cover = 0;
                $query = "INSERT INTO `tbl_projectsalesunitimage` (file_id, file_type, file_name, file_cover, unit_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$unit_id."')";
            }
            $con->query($query);
        }

        $obj->success = true;
        $obj->unit_id = $unit_id;
        $obj->message = 'Data update successfully';
    }
    exit(json_encode($obj));
}

// Remove Image

if($data['task']=='removeImage') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Image not remove';
    
    if( isset($data['file_id']) && !empty($data['file_id']) ) {
        
        $query = "DELETE FROM `tbl_productimages` WHERE file_id='".$data['file_id']."'";
        if($con->query($query) === TRUE) {
            $obj->success = true;
            $obj->message = 'Image has been removed';
        }
    }
    
    exit(json_encode($obj));
}

// Update Cover Photo

if($data['task']=='updateCoverPhoto') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Image not updated';

    if( isset($data['product_id']) && !empty($data['product_id']) && isset($data['file_id']) && !empty($data['file_id']) ) {
        
        $query = "UPDATE `tbl_productimages` SET `file_cover`='0' WHERE product_id='".$data['product_id']."'";
        if($con->query($query)) {
            $query = "UPDATE `tbl_productimages` SET `file_cover`='1' WHERE file_id='".$data['file_id']."'";
            if($con->query($query) === TRUE) {
                $obj->success = true;
                $obj->message = 'Image updated';
            }
        }
    }
    
    exit(json_encode($obj));
}

?>