<?php

require('include.php');

function prx($data = false) {
    if($data) {
        echo '<pre>'; print_r($data); echo '</pre>'; die(__FILE__);
    }else {
        echo 'No data available'; die(__FILE__);
    }
}
//o

class Helper {

    public static function getLoginUser() {
        $userid = 0;
        $user = isset($_SESSION['user']) ? $_SESSION['user'] : '';
        if($user) {
            if(isset($user['user_type']) && $user['user_type']=='admin') {
                $userid =  ( isset($user['admin_id']) && !empty($user['admin_id']) ) ? $user['admin_id'] : '';
            }elseif(isset($user['user_type']) && $user['user_type']=='customer') {
                $userid =  ( isset($user['cust_id']) && !empty($user['cust_id']) ) ? $user['cust_id'] : '';
            }else {
                $userid =  ( isset($user['cust_id']) && !empty($user['cust_id']) ) ? $user['cust_id'] : '';
            }
        }

        return $userid;
        
    }

    public static function getUserById($id = false) {
        if($id) {
            require('database.php');
            $query = "SELECT admin_id, admin_firstname, admin_lastname, admin_email, admin_group, admin_status FROM `tbl_admin` WHERE admin_id='".$id."'";	
            $result = $con->query($query);
            if($result->num_rows > 0){
                $data = $admin = $result->fetch_object();
                return $data;
            }
        }
        return false;
    }
    
    public static function getTableData($table=false) {
        require('database.php');
        $data = array();
        if(!empty($table)) {
            $sql = "SELECT * FROM `".$table."`";	
            $result = $con->query($sql);
            if($result->num_rows > 0){
                while($admin = $result->fetch_object()) {
                    $data[] = $admin;			 
                }
            }
        }
        return $data;
    }  

    public static function getParentCategories() {
        require('database.php');
        $data = array();
        $query = "SELECT * FROM tbl_categories WHERE parent_id='0' ORDER BY category_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
        }    
        return $data;
    } 

    public static function getAllCategories() {
        require('database.php');
        $data = array();
        $query = "SELECT * FROM `tbl_categories` ORDER BY category_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
        }   
        if($data) {
            $newData = array();

            foreach($data as $key=>$val) {
                if(empty($val->parent_id)) {
                    $newData[] = $val; 
                    
                    foreach($data as $val1) {
                        if($val1->parent_id==$val->category_id) {
                            $newData[] = $val1;
                        }    
                    }

                }
            }
        } 
        return $newData;
    } 

    public static function getCategoryTree() {
        require('database.php');
        $data = array();
        $query = "SELECT * FROM `tbl_categories` ORDER BY category_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
        }   
        if($data) {
            $parentCategory = array(); 
            foreach($data as $key=>$val) {
                if(empty($val->parent_id)) {
                    $childCategory = array();
                    foreach($data as $val1) {
                        if($val1->parent_id==$val->category_id) {
                            $childCategory[] = $val1;
                        }    
                    }
                    $val->child_category = $childCategory;
                    $parentCategory[] = $val;
                }
                
            }
        } 
        return $parentCategory;
    }

    public static function getCustomers() {
        require('database.php');
        $data = array();
        $query = "SELECT c.*, cg.custgroup_name FROM `tbl_customers` AS c LEFT JOIN `tbl__customersgroup` AS cg ON c.custgroup_id=cg.custgroup_id ORDER BY c.cust_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
        }    
        return $data;
    } 
// vvooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooxooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooox
    public static function getCustomerById($id = false) {
        require('database.php');
        $data = null;
        if($id) {
            $query = "SELECT c.*, cg.custgroup_name FROM `tbl_customers` AS c LEFT JOIN `tbl__customersgroup` AS cg ON c.custgroup_id=cg.custgroup_id WHERE c.cust_id='".$id."'";	
            $result = $con->query($query);
            if($result->num_rows > 0){
                while($res = $result->fetch_object()) {
                    $data = $res;			 
                }
            }    
        }
        return $data;
    } 

    public static function getCustomerGroup() {
        require('database.php');
        $data = array();
        $query = "SELECT * FROM `tbl__customersgroup` ORDER BY custgroup_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $data[] = $admin;			 
            }
        }    
        return $data;
    } 

    public static function defaultCustomerGroup() {
        require('database.php');
        $data = null;
        $query = "SELECT * FROM `tbl__customersgroup` WHERE default_group='1'";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($res = $result->fetch_object()) {
                $data = $res;			 
            }
        } else {
            $data = new stdClass();
            $data->custgroup_id = null;
        }   
        return $data;
    } 

    public static function getProducts() {
        require('database.php');
        $products = array();
        $query = "SELECT * FROM tbl__products GROUP BY product_id ORDER BY product_id DESC";
        $result = $con->query($query);
        if($result->num_rows > 0) {
            while($res = $result->fetch_object()) {
                $products[] = $res;
            }
        }
        return $products;
    }
//
    public static function getProductDetail($productId=false) {
        if($productId) {
            $id = $productId;
        }elseif(isset($_GET['product']) && $_GET['product'] > 0) {
            $id = $_GET['product'];
        }else {
            $id = false;
        }
        
        $products = new stdClass();
        if($id) {
            require('database.php');
            $query = "SELECT p.*, c.parent_id, c.category_name AS sub_category_name, pc.category_name AS parent_category_name FROM tbl__products AS p LEFT JOIN tbl_categories AS c ON p.category_id=c.category_id LEFT JOIN tbl_categories AS pc ON c.parent_id=pc.category_id WHERE p.product_id='".$id."' ";
            $result = $con->query($query);
            if($result->num_rows > 0) {
                while($res = $result->fetch_object()) {
                    $products = $res;
                }
            }
            if(empty($products)) {
                return $products;
                exit;
            }

            // All product price
            $prices = array();
            $query = "SELECT pp.*, cg.custgroup_name FROM tbl_productprices AS pp LEFT JOIN tbl__customersgroup AS cg ON pp.custgroup_id=cg.custgroup_id WHERE pp.product_id='".$products->product_id."' GROUP BY pp.price_id ORDER BY pp.price_id ASC";
            $result = $con->query($query);
            if($result->num_rows > 0) {
                while($res = $result->fetch_object()) {
                    $prices[] = $res;
                }
            }
            $products->prices = $prices;

            // All product images
            $images = array();
            $query = "SELECT * FROM tbl_productimages WHERE product_id='".$products->product_id."' GROUP BY file_id ORDER BY file_id DESC";
            $result = $con->query($query);
            if($result->num_rows > 0) {
                while($res = $result->fetch_object()) {
                    $images[] = $res;
                }
            }
            $products->images = $images;
            
        }else {
            $products->product_id = null;
            $products->product_name = null;
            $products->product_description = null;
            $products->product_quantity = null;
            $products->category_id = null;
            $products->company_id = null;
            $products->prices = null;
            $products->images = null;    
        }
        // prx($products);
        return $products;
    }

    public static function getAllProductsDetail($filter = array()) {
        $products = array();
        
        require('database.php');
        $query = "SELECT p.*, c.parent_id, c.category_name AS sub_category_name, pc.category_name AS parent_category_name FROM tbl__products AS p LEFT JOIN tbl_categories AS c ON p.category_id=c.category_id LEFT JOIN tbl_categories AS pc ON c.parent_id=pc.category_id ORDER BY p.product_id DESC ";
        $result = $con->query($query);
        if($result->num_rows > 0) {
            while($res = $result->fetch_object()) {
                $products[] = $res;
            }
        }
        if(empty($products)) {
            return $products;
            exit;
        }

        foreach($products as $key=>$product) {

            // All product price
            $prices = array();
            $query = "SELECT pp.*, cg.custgroup_name FROM tbl_productprices AS pp LEFT JOIN tbl__customersgroup AS cg ON pp.custgroup_id=cg.custgroup_id WHERE pp.product_id='".$product->product_id."' GROUP BY pp.price_id ORDER BY pp.custgroup_id ASC";
            $result = $con->query($query);
            if($result->num_rows > 0) {
                while($res = $result->fetch_object()) {
                    $prices[] = $res;
                }
            }
            $products[$key]->prices = $prices;

            // All product images
            $images = array();
            $query = "SELECT * FROM tbl_productimages WHERE product_id='".$product->product_id."' GROUP BY file_id ORDER BY file_cover DESC";
            $result = $con->query($query);
            if($result->num_rows > 0) {
                while($res = $result->fetch_object()) {
                    $images[] = $res;
                }
            }
            $products[$key]->images = $images;
        }
         
        // prx($products);
        return $products;
    }

    public static function getCartCount() {
        require('database.php');
        $userid = self::getLoginUser();
        $count = 0;
        $query = "SELECT sum(`product_quantity`) as total_quantity FROM `tbl_cart` WHERE `cust_id`='".$userid."'";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($res = $result->fetch_object()) {
                $count = $res->total_quantity;			 
            }
        }    
        return $count;
    }

    public static function getCartItems() {
        require('database.php');
        $userid = self::getLoginUser();
        $data = array();
        $query = "SELECT cart.`cart_id`, cart.`product_id`, SUM(cart.`product_quantity`) AS quantity, p.product_name FROM `tbl_cart` AS cart LEFT JOIN `tbl__products` AS p ON cart.product_id=p.product_id WHERE `cust_id`=$userid GROUP BY `product_id`";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($res = $result->fetch_object()) {
                $data[] = $res;			 
            }
        }    
        foreach($data as $key=>$value) {
            $data[$key]->product = self::getProductDetail($value->product_id);
        }
        return $data;
    }

    public static function getCustomerOrders() {
        require('database.php');
        $cust_id = self::getLoginUser();
        $orders = array();
        
        $query = "SELECT * FROM `tbl_orders` WHERE cust_id='".$cust_id."' ORDER BY order_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($res = $result->fetch_object()) {
                $orders[] = $res;			 
            }
        }    

        if($orders) {
            foreach($orders as $order_key=>$order) {
                $order_items = array();
                $order_id = $order->order_id;
                $query = "SELECT * FROM `tbl_orders_item` WHERE order_id='".$order_id."' ORDER BY item_id DESC";	
                $result = $con->query($query);
                if($result->num_rows > 0){
                    while($res = $result->fetch_object()) {
                        $order_items[] = $res;			 
                    }
                }
                
                if($order_items) {
                    foreach($order_items as $item_key=>$item) {
                        $product_id = $item->product_id;
                        $order_items[$item_key]->product = self::getProductDetail($product_id);
                    }
                }

                $orders[$order_key]->items = $order_items;

            }
        }
        
        return $orders;
    }

    public static function getAllOrders() {
        require('database.php');
        $cust_id = self::getLoginUser();
        $orders = array();
        
        $query = "SELECT o.*, c.cust_name FROM `tbl_orders` AS o LEFT JOIN `tbl_customers` AS c ON o.cust_id=c.cust_id ORDER BY o.order_id DESC";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($res = $result->fetch_object()) {
                $orders[] = $res;			 
            }
        }  
        
        if($orders) {
            foreach($orders as $order_key=>$order) {
                $query = "SELECT SUM(`item_price`) AS `amount`, SUM(`item_quantity`) AS `quantity`, SUM(`item_discount`) AS `discount` FROM `tbl_orders_item` WHERE `order_id`='".$order->order_id."' GROUP BY `order_id` ORDER BY `item_id` ";
                if($result = $con->query($query)) {
                    $res = $result->fetch_object();
                    $orders[$order_key]->amount = $res->amount;
                    $orders[$order_key]->quantity = $res->quantity;
                    $orders[$order_key]->discount = $res->discount;
                }
            }
        }
        
        return $orders;
    }


//     
    public static function getCompanyId() {
        require('database.php');
        $userid = self::getLoginUser();
        $companyid = 0;
        $query = "SELECT company_id FROM tbl_admin WHERE admin_id='".$userid."'";	
        $result = $con->query($query);
        if($result->num_rows > 0){
            while($admin = $result->fetch_object()) {
                $companyid = $admin->company_id;			 
            }
        }    
        return $companyid;
    } 

    public static function display_Text($text = false, $no = false) {
        if($text) {
            $defaultNo = 15;
            $text = trim($text);
            $characterCount = $no?$no:$defaultNo;

            if(strlen($text) > $characterCount) {
                $subString = substr($text, 0, $characterCount);
                return $subString.'...';
            }
            return $text;
        }
        return '';
    }

    public static function clean_string($string='') {
        return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
     }

    public static function checkSuperAdminGroup($id = false) {
        if($id==false) {
            $id = self::getLoginUser();
        }
        if($id) {
            require('database.php');
            $query = "SELECT * FROM `administrators` WHERE admin_id='".$id."' AND admin_group='SYS_ADMIN'";	
            $result = $con->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public static function checkAdminGroup($id = false) {
        if($id==false) {
            // $id = self::getLoginUser();
            $user = isset($_SESSION['user']) ? $_SESSION['user'] : '';
            if($user) {
                if($user['user_type']=='admin') {
                    $id =  ( isset($user['admin_id']) && !empty($user['admin_id']) ) ? $user['admin_id'] : '';
                }
            }
        }
        if($id) {
            require('database.php');
            $query = "SELECT * FROM `tbl_admin` WHERE admin_id='".$id."'";	
            $result = $con->query($query);
            // prx($result);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public static function checkCustomerGroup($id = false) {
        if($id==false) {
            // $id = self::getLoginUser();
            $user = isset($_SESSION['user']) ? $_SESSION['user'] : '';
            if($user) {
                if($user['user_type']=='customer') {
                    $id =  ( isset($user['cust_id']) && !empty($user['cust_id']) ) ? $user['cust_id'] : '';
                }
            }
        }
        if($id) {
            require('database.php');
            $query = "SELECT * FROM `tbl_customers` WHERE cust_id='".$id."'";	
            $result = $con->query($query);
            // prx($result);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public static function checkExternalAgentGroup($id = false) {
        if($id==false) {
            $id = self::getLoginUser();
        }
        if($id) {
            require('database.php');
            $query = "SELECT * FROM `administrators` WHERE admin_id='".$id."' AND admin_group='USER_EXTERNAL'";	
            $result = $con->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }
    

    public static function getAllUsers() {
        require('database.php');
        $data = array();
        $filter = '';
        if(isset($_POST['filter']) && !empty($_POST['filter'])){
            $last = date('Y-m-d', strtotime('-30 days'));
            if($_POST['filter']=='Last'){
                $sql = "SELECT * FROM users WHERE created >='".$last."'";
            }else if($_POST['filter']=='After'){
                $sql = "SELECT * FROM users WHERE created <='".$last."'";
            }else{
                $sql = "SELECT * FROM users ";
            }
            $filter = $_POST['filter'];
        }else{
            $sql = "SELECT * FROM users WHERE active=1 AND user_type='customer' || user_type='admin' GROUP BY id ORDER BY user_type ASC";	
        }

        $result = $conn->query($sql);
        if($result->num_rows > 0){
            while($user = $result->fetch_assoc()) {
                $data[] = $user;			 
            }
            return $data;
        }
        return false;
    }

    public static function getAllUsersPlan($filterByStatus) {
        require('database.php');
        $data = array();
        $filter = '';
        if(isset($filterByStatus) && !empty($filterByStatus)){
            $sql = "SELECT u.id as userid, u.name as username, u.status, u.admin, u.package, u.account, u.website_setup_date, u.training_date, u.revision_1, u.revision_2, u.website_buy_off_date,u.cpanel_password, u.wordpress_password, p.id, p.logo, p.about_us, p.shipping, p.payment, p.contactinfo, p.socialmedia, p.domainemail, p.websitedesign, logo.logo as isLogo, aboutus.content as isAbout, shipping.id as isShipping, payment.id as isPayment, contactinfo.id as isContact, socialmedia.id as isSocialmedia, domainemail.id as isDomainemail, websitedesign.id as isWebsitedesign FROM users as u left join plan as p on u.id=p.userid left join logo on u.id=logo.userid left join aboutus on u.id=aboutus.userid left join shipping on u.id=shipping.userid left join payment on u.id=payment.userid left join contactinfo on u.id=contactinfo.userid left join socialmedia on u.id=socialmedia.userid left join domainemail on u.id=domainemail.userid left join websitedesign on u.id=websitedesign.userid WHERE u.user_type='customer' AND u.status='".$filterByStatus."' ORDER BY u.id DESC";
        }else{
            $sql = "SELECT u.id as userid, u.name as username, u.status, u.admin, u.package, u.account, u.website_setup_date, u.training_date, u.revision_1, u.revision_2, u.website_buy_off_date,u.cpanel_password, u.wordpress_password, p.id, p.logo, p.about_us, p.shipping, p.payment, p.contactinfo, p.socialmedia, p.domainemail, p.websitedesign, logo.logo as isLogo, aboutus.content as isAbout, shipping.id as isShipping, payment.id as isPayment, contactinfo.id as isContact, socialmedia.id as isSocialmedia, domainemail.id as isDomainemail, websitedesign.id as isWebsitedesign FROM users as u left join plan as p on u.id=p.userid left join logo on u.id=logo.userid left join aboutus on u.id=aboutus.userid left join shipping on u.id=shipping.userid left join payment on u.id=payment.userid left join contactinfo on u.id=contactinfo.userid left join socialmedia on u.id=socialmedia.userid left join domainemail on u.id=domainemail.userid left join websitedesign on u.id=websitedesign.userid WHERE u.user_type='customer' ORDER BY u.id DESC";	
        }
        $result = $conn->query($sql);
        
        if($result->num_rows > 0){
            while($user = $result->fetch_assoc()) {
                $data[] = $user;			 
            }
            return $data;
        }
        return false;
    }

    public static function getAllAdmin() {
        require('database.php');
        $data = array();
        
        $sql = "SELECT * FROM users WHERE user_type='admin'";	
        $result = $conn->query($sql);
        if($result->num_rows > 0){
            while($admin = $result->fetch_assoc()) {
                $data[] = $admin;			 
            }
            return $data;
        }
        return false;
    }

    public function getUserId() {
        $user = $_SESSION['user'];
        return $user['cust_id'];
    }

    

    public function getUser() {
        $user = $_SESSION['user'];
        return $user;
    }

    public function getUserInfoData() {
        $user = $_SESSION['user'];
        require('database.php');
        $query = "SELECT u.id as userid, logo.logo as isLogo, aboutus.content as isAbout, shipping.id as isShipping, payment.id as isPayment, contactinfo.id as isContact, socialmedia.id as isSocialmedia, domainemail.id as isDomainemail, websitedesign.id as isWebsitedesign FROM users as u left join logo on u.id=logo.userid left join aboutus on u.id=aboutus.userid left join shipping on u.id=shipping.userid left join payment on u.id=payment.userid left join contactinfo on u.id=contactinfo.userid left join socialmedia on u.id=socialmedia.userid left join domainemail on u.id=domainemail.userid left join websitedesign on u.id=websitedesign.userid WHERE u.id=".$user['id']." AND u.user_type='customer' ";
        $result = $conn->query($query);	
        if($result->num_rows > 0){
            $data = $result->fetch_assoc();
            return $data;
        }
        return false;
    }

    // public function checkLogoExist($userid=false) {
    //     if($userid) {
    //         require('database.php');
    //         require('constant.php');
    //         $query = 'SELECT * FROM logo WHERE userid="'.$userid.'"';
    //         $result = $conn->query($query);
    //         if($result->num_rows > 0){
    //             $logo = $result->fetch_assoc();
    //             $logoname = $logo['logo'];
    //             unlink(LOGO_PATH.$logoname);
    //             return true;
    //         }
    //     }
    //     return false;
    // }

    public function checkAboutusExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM aboutus WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function checkShippingExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM shipping WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function checkPaymentExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM payment WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function checkContactinfoExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM contactinfo WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function checkSocialmediaExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM socialmedia WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function checkDomainemailExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM domainemail WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function checkWebsitedesignExist($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM websitedesign WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return true;
            }
        }
        return false;
    }

    public function getUserLogo($userid=false) {
        if($userid) {
            require('database.php');
            $query = 'SELECT * FROM logo WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                $logo = $result->fetch_assoc();
                return $logo['logo'];
            }
        }
        return false;
    }

    public function getUserTemplete($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM aboutus WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                $templete = $result->fetch_assoc();
                $obj->templete = $templete['templete'];
                $obj->content = $templete['content'];
                $obj->photo = $templete['photo'];
                return $obj;
            }
        }
        return false;
    }

    public function getUserShipping($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM shipping WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }
        }
        return false;
    }

    public function getUserPayment($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM payment WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }
        }
        return false;
    }

    public function getUserContactinfo($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM contactinfo WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }
        }
        return false;
    }

    public function getUserSocialmedia($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM socialmedia WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }
        }
        return false;
    }

    public function getUserDomainemail($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM domainemail WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }
        }
        return false;
    }

    public function getUserWebsiteDesign($userid=false) {
        if($userid) {
            require('database.php');
            $obj = new stdClass();
            $query = 'SELECT * FROM websitedesign WHERE userid="'.$userid.'"';
            $result = $conn->query($query);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }
        }
        return false;
    }

}



?>