<?PHP

$data = Fetch::getProjectSale();
$states =  Fetch::getState();
$cities =  Fetch::getCity();
$filter = $_POST;
?>

<style>
.project-sale-listing-image {
    width: 100%;
    height: 100px; 
}
.listing-cover-photo {
    padding-left: 0px;
}

.project-sale-main-container {
    border: solid 1px #f5f5f5;
    box-shadow: 0px 1px 5px #696969;
    padding: 15px;
    margin: 10px;
}
.project-sale-button-main {
    margin-top: 10px;
}
.filter-row {
    margin: 10px;
}
.filter-select {
    width: 60%;
}
.set-reset-btn {
    float:right;
}

.filter-box, .filter-box>label {
    padding-left: 0px;
}

.filter-box>input, .filter-box>select {
    width: 65% !important;
}

@media only screen and (max-width: 768px) {
    .set-reset-btn {
        float: right;
        display: block;
    }
    
    .listing-cover-photo {
        padding: 0px 0px 10px;
    }
    
    .filter-row {
        margin: 0px 10px;
    }
    
    .filter-box {
        padding-left: 0px;
        padding-right: 0px;
        
    }
    
    .filter-box>input, .filter-box>select {
        float: left;
        margin-bottom: 10px;
        width: 75% !important;
    }
    
    .filter-box>label {
        float: left;
        width: 25% !important;
    }
    
    #filter_form {
        padding-top: 15px;
    }
    
    .project-sale-listing-image {
        width: 100%;
        height: 185px;
    }
}
</style>
<!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            
            
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid" >
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                
                <section id="main-content">
                <section class="wrapper">
                <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Project Sale Listing</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb" style="margin-bottom:0;">
                                    <li class="breadcrumb-item"><a href="<?=BASE_URL.'index.php'?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'index.php?page=projectsale_listing'?>">Project Sale Listing</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            
                <div class="main-container">
                    <form name="filter_form" class="form-inline" id="filter_form" action="" method="POST" role="form">
                        <div class="row filter-row ">
                            <div class="col-sm-3 filter-box form-group">
                                <label for="keywords" class="col-sm-4 text-left control-label col-form-label">Keywords</label>
                                <input type="text" class="resetValue form-control" name="filter_keywords" value="<?=isset($filter['filter_keywords'])?$filter['filter_keywords']:''?>">   
                            </div>

                            <div class="col-sm-3 filter-box form-group">
                                <label for="project" class="col-sm-4 text-left control-label col-form-label">Project</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="filter_project">
                                    <option value=""> --Select Project-- </option>
                                    <?php 
                                        $options = Fetch::getDataByTableName('projects');
                                        foreach($options as $key=>$option) { 
                                            $option_selected = ($filter['filter_project']==$option->project_id)?' selected':'';  
                                    ?>
                                        
                                        <option value="<?=$option->project_id?>" <?=$option_selected?>><?=$option->project_title?></option>
                                    <?php } ?>
                                </select>  
                            </div>

                            <div class="col-sm-3 filter-box form-group">
                                <label for="city" class="col-sm-4 text-left control-label col-form-label">City</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="filter_city">
                                    <option value=""> --Select City-- </option>
                                    <?php 
                                        $options = Fetch::getDataByTableName('city');
                                        foreach($options as $key=>$option) { 
                                            $option_selected = ($filter['filter_city']==$option->city_id)?' selected':'';  
                                    ?>
                                        
                                        <option value="<?=$option->city_id?>" <?=$option_selected?>><?=$option->city_title?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="col-sm-3 filter-box form-group">
                                <label for="facing" class="col-sm-4 text-left control-label col-form-label">Facing</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="filter_facing">
                                    <option value=""> --Select Facing-- </option>
                                    <?php 
                                        $options = Fetch::getDataByTableName('facing');
                                        foreach($options as $key=>$option) { 
                                            $option_selected = ($filter['filter_facing']==$option->facing_id)?' selected':'';  
                                    ?>
                                        
                                        <option value="<?=$option->facing_id?>" <?=$option_selected?>><?=$option->facing_title?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="row filter-row">
                            <div class="col-sm-3 filter-box form-group">
                                <label for="listing" class="col-sm-4 text-left control-label col-form-label">Listing</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="listing_type">
                                    <!-- <option value=""> --Select Listing-- </option> -->
                                    <option value="Project Sale"> Project Sale </option>
                                    
                                </select>  
                            </div>

                            <div class="col-sm-3 filter-box form-group">
                                <label for="road_name" class="col-sm-4 text-left control-label col-form-label">Road Name</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="filter_road_name">
                                    <option value=""> --Select Road Name-- </option>
                                    <?php 
                                        $options = Fetch::getDataByTableName('project_road_name');
                                        foreach($options as $key=>$option) { 
                                            $option_selected = ($filter['filter_road_name']==$option->project_road_id)?' selected':'';  
                                    ?>
                                        
                                        <option value="<?=$option->project_road_id?>" <?=$option_selected?>><?=$option->road_name?></option>
                                    <?php } ?>
                                </select>  
                            </div>

                            <div class="col-sm-3 filter-box form-group">
                                <label for="reserve" class="col-sm-4 text-left control-label col-form-label">Reserve</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="filter_reserve">
                                    <option value=""> --Select Reserve-- </option>
                                    <?php 
                                        $options = Fetch::getDataByTableName('reserve');
                                        foreach($options as $key=>$option) { 
                                            $option_selected = ($filter['filter_reserve']==$option->reserve_id)?' selected':'';  
                                    ?>
                                        
                                        <option value="<?=$option->reserve_id?>" <?=$option_selected?>><?=$option->reserve_title?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="col-sm-3 filter-box form-group">
                                <label for="category" class="col-sm-4 text-left control-label col-form-label">Category</label>
                                <select class="filter-select filter-on-change resetValue form-control" name="filter_category">
                                    <option value=""> --Select Category-- </option>
                                    <?php 
                                        $options = Fetch::getDataByTableName('category');
                                        foreach($options as $key=>$option) { 
                                            $option_selected = ($filter['filter_category']==$option->category_id)?' selected':'';  
                                    ?>
                                        
                                        <option value="<?=$option->category_id?>" <?=$option_selected?>><?=$option->category_title?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="row filter-row">
                            <div class="col-sm-9 filter-box">
                            </div>
                            <div class="col-sm-3 filter-box">
                                <button type="button" class="filter-btn reset btn btn-primary set-reset-btn" style="">Reset</button>
                                <button type="button" class="filter-btn search btn btn-primary set-reset-btn" style=" margin-right:5px" >Search</button>
                            </div>
                        </div>
                        
                        
                    </form>
                </div> 
                <div class="row" >
                    <div class="col-md-12">
                        
                        <?php
                        
                        Foreach($data as $key=>$value) {

                        ?>

                        
                        <div class="col-md-4" style="padding: 0 !important;">
                            <div class="row project-sale-main-container" style="background-color: #fff;">
                                <div class="col-md-5 listing-cover-photo">
                                    <?php if($value->file_name) { ?>
                                    <img src="<?=BASE_URL.UPLOAD_IMAGE_PATH.$value->file_name?>" class="project-sale-listing-image">
                                    <?php }else{ ?>
                                    <img src="<?=BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png'?>" class="project-sale-listing-image">    
                                    <?php } ?>
                                </div>

                                <div class="col-md-7" style="padding: 0;">
                                    <p> <?=$value->listing_type?> </p>
                                    <p> Project:<?php echo Helper::display_Text ($value->project_title_name, 12); ?> </p>
                                    <p> Reserve: <?php echo Helper::display_Text ($value->reserve_title, 11); ?> </p>
                                    
                                </div>
                                
                                <div class="col-md-12 project-sale-button-main" style="padding-left: 0;">
                                    <a href="<?=BASE_URL.'index.php?page=projectsale_edit&id='.$value->property_id.'&layout=0'?>" class="btn btn-theme" class="project-sale-modify-btn"> <i class="fa fa-cog"></i> Modify </a>
                                    <a href="<?=BASE_URL.'index.php?page=projectsale_view&id='.$value->property_id?>" class="btn btn-theme02" class="project-sale-view-btn"><i class="fa fa-eye"></i> View </a>

                                    <!-- <a href="#" class="btn btn-theme04"> Remove</a> -->
                                </div>
                                
                                
                            </div>
                        </div>
                        
                        
                        <?php
                           
                        }
                        
                        ?>
                    </div>
                </div> 
                <div class="row" >
                    <div class="col-md-4">
                        <div class="main-container">
                            
                        </div>
                    </div>
                </div> 
                </section>      
                </section>      
               
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            <script>
            
            $(document).on('click', '.filter-btn', function(){
                if($(this).hasClass('reset')) {
                    $('.resetValue').val('');
                }
                $('#filter_form').submit();
            });
            </script>