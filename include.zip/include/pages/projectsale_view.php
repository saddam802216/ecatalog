<?PHP
$id = null;
if(isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
}
 
$data = Fetch::getProjectSaleByID($id); 
$unitInfo = $data->unitInfo;
// prx($data);
?>

<style>
.loader {
    position: fixed;
    z-index: 999;
    /* height: 2em;
    width: 2em; */
    overflow: show;
    margin: auto;
    top: 0%;
    left: 0%;
    bottom: 0;
    right: 0;
    background-color: #00000055;
    display: none;
}
.loader img {
    position: relative;
    top: 50%;
    left: 50%;
}
.view-table>tbody>tr>td{
    border: none;
}


/* The Modal (background) */
.img-modal {
  display: none;
  position: fixed;
  z-index: 9999;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: black;
}

/* Modal Content */
.img-modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  width: 50%;
  max-width: 1200px;
}
/* The Close Button */
.img-close {
  color: white;
  position: absolute;
  top: 10px;
  right: 25px;
  font-size: 35px;
  font-weight: bold;
}
.img-close:hover,
.img-close:focus {
  color: #999;
  text-decoration: none;
  cursor: pointer;
}
.log_remarks {
    width: 100%;
    margin-top: 10px;
    padding: 10px;
    height: 80px;
}
.td-w-25 {
    width:25% !important;
}
.td-w-60 {
    width:60% !important;
}

@media only screen and (max-width: 768px) {
    .content-panel {
        overflow-x: auto;
    }
}
</style>
<!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid" >
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="loader">
                    <img src="<?=BASE_URL.SITE_IMAGE_PATH.'loader-color.gif'?>" >
                </div>

                <section id="main-content">
                <section class="wrapper">

<!-- ============================================================== -->
            <!-- Start Bread crumb  -->
<!-- ============================================================== -->                
                
                <div class="page-breadcrumb">
                    <div class="row">
                        <div class="col-md-12 d-flex no-block align-items-center">
                            <h4 class="page-title">Project Sale View</h4>
                            <div class="ml-auto text-right">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb" style="margin-bottom:0;">
                                        <li class="breadcrumb-item"><a href="<?=BASE_URL.'index.php'?>">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'index.php?page=projectsale_view'?>">Project Sale View</a></li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

<!-- ============================================================== -->
            <!-- End Bread crumb  -->
<!-- ============================================================== -->  


<!-- ============================================================== -->
            <!-- Start Project Info  -->
<!-- ============================================================== -->   


                <div class="row" >
                    <div class="col-md-12"> <h3> Sale Info </h3> </div>
                    <input type="hidden" id="project_id" value="<?=$data->property_id?>" >



<!-- ============================================================== -->
            <!-- Start Project Sale Info At Left Side  -->
<!-- ============================================================== -->   
                    

                    <div class="col-md-6 sale-info-table">
                        <div class="main-container">
                            <table class="table table-borderless view-table">
                                <tbody>
                                    <tr>
                                        <td class="td-w-25">Listing Type</td>
                                        <td>:</td>
                                        <td class="td-w-60"><?=$data->listing_type?></td>
                                    </tr>

                                    <tr>
                                        <td>Property ID</td>
                                        <td>:</td>
                                        <td><?=$data->property_id?></td>
                                    </tr>

                                    <tr>
                                        <td>Project Title</td>
                                        <td>:</td>
                                        <td><?=$data->project_title_name?></td>
                                    </tr>

                                    <tr>
                                        <td>Road Name</td>
                                        <td>:</td>
                                        <td><?=$data->road_name_title?></td>
                                    </tr>

                                    <tr>
                                        <td>State</td>
                                        <td>:</td>
                                        <td><?=$data->state_title?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>City</td>
                                        <td>:</td>
                                        <td><?=$data->city_title?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Tenure</td>
                                        <td>:</td>
                                        <td><?=$data->tenure_title?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Reserve</td>
                                        <td>:</td>
                                        <td><?=$data->reserve_title?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Commission</td>
                                        <td>:</td>
                                        <td><?=$data->commission_title?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Poster/Banner</td>
                                        <td>:</td>
                                        <?php $pb = unserialize(POSTER_BANNER) ?>
                                        <td><?=$pb[$data->poster_banner]?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Advertisement Date</td>
                                        <td>:</td>
                                        <td><?=$data->ads_date?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Remarks</td>
                                        <td>:</td>
                                        <td><?=$data->remarks?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Listing Date</td>
                                        <td>:</td>
                                        <td><?=$data->listing_date?></td>
                                    </tr>

                                    <tr>
                                        <td>Listing By</td>
                                        <td>:</td>
                                        <?php $user = Helper::getUserById($data->listing_by) ?>
                                        <td><?=$user->admin_firstname?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Bring In By</td>
                                        <td>:</td>
                                        <?php $user = Helper::getUserById($data->bringin_by) ?>
                                        <td><?=$user->admin_firstname?></td>
                                    </tr>

                                    
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>


<!-- ============================================================== -->
            <!-- End Project Sale Info At Left Side  -->
<!--==============================================================-->      


<!-- ============================================================== -->
            <!-- Start Project Sale Info At  Right Side  -->
<!-- ============================================================== -->   
                    <div class="col-md-6">
                        <div class="main-container">
                            <div id="myCarousel" class="carousel slide" data-interval="false">
                                <!-- Wrapper for slides -->
                                <div class="carousel-inner">
                                    <?php
                                        $isCoverPhoto = false;
                                        for($j=0; $j<count($data->projectSaleImage); $j++) {
                                            $active = ($data->projectSaleImage[$j]->file_cover)?' active':'';
                                            if($active) {
                                                $isCoverPhoto = true;
                                            }

                                    ?>

                                    <div class="item <?=$active?>">
                                        <img src="<?=BASE_URL.UPLOAD_IMAGE_PATH.$data->projectSaleImage[$j]->file_name?>" alt="Los Angeles" style="width:100%; height:260px">
                                    </div>

                                    <?php  
                                    
                                        } 
                                    
                                        if(!$isCoverPhoto) {

                                    ?>

                                    <div class="item active">
                                        <img src="<?=BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png'?>" alt="Los Angeles" style="width:100%; height:260px">
                                    </div>
                                    
                                    <?php
                                            
                                        }
                                    ?>

                                </div>

                                <!-- Left and right controls -->
                                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                                <span class="sr-only">Previous</span>
                                </a>
                                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                                <span class="sr-only">Next</span>
                                </a>
                            </div>
                            <!-- image right -->
                            <div class="row">
                                <?php
                                    $imgIndex = 1;
                                    for($j=0; $j<count($data->projectSaleImage); $j++) {
                                        if($data->projectSaleImage[$j]->file_cover) {
                                            continue;
                                        }
                                ?>
                                <div class="col-sm-4 column" style="padding-top: 10px;">
                                    <img src="<?=BASE_URL.UPLOAD_IMAGE_PATH.$data->projectSaleImage[$j]->file_name?>" style="width:100%; height:120px" onclick="openModal();currentSlide(<?=$imgIndex?>)" class="hover-shadow cursor">
                                </div>
                        
                                <?php $imgIndex++; } ?>

                            </div>
                            
                            <!--  image modal -->

                            <div id="imgModal" class="modal img-modal">
                                <span class="img-close cursor" onclick="closeModal()">&times;</span>
                                <div class="modal-content img-modal-content">

                                    <?php
                                    
                                    for($j=0; $j<count($data->projectSaleImage); $j++) {
                                        if($data->projectSaleImage[$j]->file_cover) {
                                            continue;
                                        }
                                    ?>

                                    <div class="mySlides">
                                        <img src="<?=BASE_URL.UPLOAD_IMAGE_PATH.$data->projectSaleImage[$j]->file_name?>" style="width:100%">
                                    </div>

                                    <?php  } ?>  
                                </div>
                            </div>
                            
                            <!-- end of image modal -->
                            
                            <?php if(isset($data->projectSaleYouTube->file_name) && !empty($data->projectSaleYouTube->file_name)) { ?>            
                            <div class="row">
                                <div class="col-sm-12" style="padding-top: 10px;">
                                <?php
                                $videolink = $data->projectSaleYouTube->file_name;
                                $ytarray=explode("/", $videolink);
                                $ytendstring=end($ytarray);
                                $ytendarray=explode("?v=", $ytendstring);
                                $ytendstring=end($ytendarray);
                                $ytendarray=explode("&", $ytendstring);
                                $ytcode=$ytendarray[0];
                                ?>

                                <iframe width="100%" height="315" src="<?="http://www.youtube.com/embed/".$ytcode?>"> </iframe>
                                </div>
                            </div>
                            <?php } ?>

                        </div>
                    </div>


<!-- ============================================================== -->
            <!-- End Project Sale Info At Right Side  -->
<!-- ============================================================== -->                       



<!-- ============================================================== -->
            <!-- Start Project Sale Unit Info Table  -->
<!-- ============================================================== -->   

                    <div class="col-md-12">
                        <h3>Unit Info </h3>
                        <?php //prx($data); ?>
                        <div class="content-panel">
                            <table class="table table-striped table-advance table-hover">
                                
                                <thead>
                                <tr>
                                    <th>PNo</th>
                                    <th>Facing</th>
                                    <th>Land Area</th>
                                    <th>Build Up</th>
                                    <th>Type</th>
                                    <th>S&P Price</th>
                                    <th>Promo Price</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Agent</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                // prx($unitInfo);
                                foreach($unitInfo as $key=>$unit) {
                                    
                                    $pnoArray = array();
                                    $sub_pno = $unit->pno;
                                    if(!empty($unit->pno)) {
                                        $pnoArray = explode(',', $unit->pno);
                                        for($l=0; $l<count($pnoArray); $l++) {      
                                            $sub_pno = str_replace(' ', '_', $pnoArray[$l]);
                                            $org_pno = $pnoArray[$l];

                                            // Log info
                                            $logData = '';
                                            for($a=0; $a<count($unit->logInfo); $a++){
                                                if($unit->logInfo[$a]->pno==$org_pno) {
                                                    $logData = $unit->logInfo[$a];
                                                }
                                            }
                                        
                                ?>
                                <tr>

                                    <td><?=$org_pno?></td>
                                    <td><?=$unit->facing_title?></td>
                                    <td><?=$unit->land_area?></td>
                                    <td><?=$unit->built_up?></td>
                                    <td><?=$unit->type_title?></td>
                                    <td><?=$unit->snp_price?></td>
                                    <td><?=$unit->promotion_price?></td>
                                    <td class="status-<?=$key.$sub_pno?>"> <?php echo (isset($logData->pno) && $logData->pno==$org_pno)?$logData->remarks:' - ' ?> </td>
                                    <td class="date-<?=$key.$sub_pno?>"> <?php echo (isset($logData->pno) && $logData->pno==$org_pno)?$logData->date:' - ' ?> </td>

                                    <?php
                                            $logAgent = '';               
                                            if(isset($logData->pno) && $logData->pno==$org_pno) {
                                                $agentID = $logData->user_id;
                                                $agent = Helper::getUserById($agentID);
                                                $logAgent = $agent->admin_firstname;
                                            }
                                    
                                    ?>
                                    <td class="agent-<?=$key.$sub_pno?>"> <?php echo !empty($logAgent)?$logAgent:' - ' ?> </td>
                                    
                                    <td>
                                    <button class="btn btn-success btn-xs updateStatus" data-id="<?=$unit->unit_id?>" data-pno="<?=$org_pno?>" data-rowId="<?=$key.$sub_pno?>" data-toggle="modal"  data-target="#updateStatus"> <i class="fa fa-pencil"></i></button>
                                    <button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#unit-info-<?=$key.$sub_pno?>"><i class="fa fa-eye"></i></button>
                                    <!-- Checks for external user -->
                                    <?php if(!(Helper::checkExternalAgentGroup())) { ?>
                                    <button class="btn btn-danger btn-xs propertyLog" modal-id="propertyLog" data-id="<?=$unit->unit_id?>" data-pno="<?=$org_pno?>" data-toggle="modal" data-target="#propertyLog"><i class="fa fa-file "></i></button>
                                    <?php } ?>
                                    <!-- Checks for external user -->
                                    </td>
                                    <input type="hidden" class="layout_id" value="<?=$unit->unit_id?>">
                                </tr>

                              

                                <?php } } }?>
                                
                                </tbody>
                            </table>
                        </div>
                    </div>


<!-- ============================================================== -->
            <!-- End Project Sale Unit Info Table  -->
<!-- ==============================================================-->     


                </div> 


<!-- ============================================================== -->
            <!-- End Project Info  -->
<!-- ============================================================== -->                   

<?php
    foreach($unitInfo as $key=>$unit) { 
        
        $pnoArray = array();
        $sub_pno = $unit->pno;
        if(!empty($unit->pno)) {
            $pnoArray = explode(',', $unit->pno);
            for($l=0; $l<count($pnoArray); $l++) {      
                $sub_pno = str_replace(' ', '_', $pnoArray[$l]);
                $org_pno = $pnoArray[$l];

                // Log info
                $logData = '';
                for($a=0; $a<count($unit->logInfo); $a++){
                    if($unit->logInfo[$a]->pno==$org_pno) {
                        $logData = $unit->logInfo[$a];
                    }
                }
                // agent name
                $logAgent = '';
                if(isset($logData->pno) && $logData->pno==$org_pno) {
                    $agentID = $logData->user_id;
                    $agent = Helper::getUserById($agentID);
                    $logAgent = $agent->admin_firstname;
                }
                // Remarks
                $logRemarks = (isset($logData->pno) && $logData->pno==$org_pno)?$logData->remarks:'';
                //Date
                $logDate = (isset($logData->date) && $logData->pno==$org_pno)?$logData->date:'';
?>


<!-- ============================================================== -->
            <!-- Start Modal Popup  -->
<!-- ============================================================== --> 

<!-- View Unit Info Modal-->
<div id="unit-info-<?=$key.$sub_pno?>" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Unit <?=$org_pno?></h4>
            </div>
            <div class="modal-body">
                <div class="col-sm-12">
                    <table class="table table-borderless view-table">
                        <tbody>
                            <tr>
                                <td class="td-w-25">PNo</td>
                                <td>:</td>
                                <td class="td-w-60"><?=$org_pno?></td>
                            </tr>

                            <tr>
                                <td>Facing</td>
                                <td>:</td>
                                <td><?=$unit->facing_title?></td>
                            </tr>

                            <tr>
                                <td>Land Area SQFT</td>
                                <td>:</td>
                                <td><?=$unit->land_area?></td>
                            </tr>

                            <tr>
                                <td>Build Up SQFT</td>
                                <td>:</td>
                                <td><?=$unit->built_up?></td>
                            </tr>

                            <tr>
                                <td>Category</td>
                                <td>:</td>
                                <td><?=$unit->category_title?></td>
                            </tr>
                            
                            <tr>
                                <td>Type</td>
                                <td>:</td>
                                <td><?=$unit->type_title?></td>
                            </tr>
                            
                            <tr>
                                <td>Concept</td>
                                <td>:</td>
                                <td><?=$unit->concept_title?></td>
                            </tr>
                            
                            <tr>
                                <td>Room</td>
                                <td>:</td>
                                <td><?=$unit->room?></td>
                            </tr>
                            
                            <tr>
                                <td>Bathroom</td>
                                <td>:</td>
                                <td><?=$unit->bathroom?></td>
                            </tr>
                            
                            <tr>
                                <td>Flooring</td>
                                <td>:</td>
                                <td><?=$unit->flooring?></td>
                            </tr>
                            
                            <tr>
                                <td>S&P Price</td>
                                <td>:</td>
                                <td><?=$unit->snp_price?></td>
                            </tr>
                            
                            <tr>
                                <td>Promo Price</td>
                                <td>:</td>
                                <td><?=$unit->promotion_price?></td>
                            </tr>
                            
                            <tr>
                                <td>Status</td>
                                <td>:</td>
                                <td class="status-<?=$key.$sub_pno?>"><?=$logRemarks?></td>
                            </tr>

                            <tr>
                                <td>Date</td>
                                <td>:</td>
                                <td class="date-<?=$key.$sub_pno?>"><?=$logDate?></td>
                            </tr>
                            
                            <tr>
                                <td>Agent</td>
                                <td>:</td>
                                <td class="agent-<?=$key.$sub_pno?>"><?=$logAgent?></td>
                            </tr> 
                        </tbody>
                    </table> 
                </div>
                <div class="col-md-12">
                    <div class="main-container">
                        <div id="unitCarousel-<?=$key.$sub_pno?>" class="carousel slide" data-interval="false">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <?php
                                    $isCoverPhoto = false;
                                    for($j=0; $j<count($unitInfo[$key]->unitInfoImages); $j++) {
                                        $active = ($unitInfo[$key]->unitInfoImages[$j]->file_cover)?' active':'';
                                        if($active) {
                                            $isCoverPhoto = true;
                                        }
                                ?>

                                <div class="item <?=$active?>">
                                    <img src="<?=BASE_URL.UPLOAD_UNITINFO_IMAGE_PATH.$unitInfo[$key]->unitInfoImages[$j]->file_name?>" alt="Los Angeles" style="width:100%; height:260px">
                                </div>

                                <?php  
                                        
                                    } 
                                
                                    if(!$isCoverPhoto) {

                                ?>

                                <div class="item active">
                                    <img src="<?=BASE_URL.SITE_IMAGE_PATH.'no-photo-available.png'?>" alt="Los Angeles" style="width:100%; height:260px">
                                </div>
                                
                                <?php
                                        
                                    }
                                ?>

                            </div>

                            <!-- Left and right controls -->
                            <a class="left carousel-control" href="#unitCarousel-<?=$key.$sub_pno?>" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                            <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#unitCarousel-<?=$key.$sub_pno?>" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="sr-only">Next</span>
                            </a>
                        </div>
                        <div class="row" style="margin-top: 10px;">
                            <?php
                                for($j=0; $j<count($unitInfo[$key]->unitInfoImages); $j++) {
                                    if($unitInfo[$key]->unitInfoImages[$j]->file_cover) {
                                        continue;
                                    }
                            ?>
                            <div class="col-sm-4 col-xs-6" style="padding-top: 10px;">
                                <img src="<?=BASE_URL.UPLOAD_UNITINFO_IMAGE_PATH.$unitInfo[$key]->unitInfoImages[$j]->file_name?>" alt="Los Angeles" style="width:100%; height:120px">
                            </div>

                            <?php  } ?>

                        </div>

                        <?php if(isset($unitInfo[$key]->projectSaleUnitYouTube->file_name) && !empty($unitInfo[$key]->projectSaleUnitYouTube->file_name)) { ?>
                        <div class="row">
                            <div class="col-sm-12" style="padding-top: 10px;">
                            <?php
                            $videolink = $unitInfo[$key]->projectSaleUnitYouTube->file_name;
                            $ytarray=explode("/", $videolink);
                            $ytendstring=end($ytarray);
                            $ytendarray=explode("?v=", $ytendstring);
                            $ytendstring=end($ytendarray);
                            $ytendarray=explode("&", $ytendstring);
                            $ytcode=$ytendarray[0];
                            
                            ?>

                            <iframe width="100%" height="315" src="<?="http://www.youtube.com/embed/".$ytcode?>"> </iframe>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>                           
            </div>
            <div class="modal-footer" style="border-top: 0;">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="margin-top:20px;"> Close       </button>
            </div>
        </div>
    </div>
</div>  
<!--End View Unit Info Modal-->



<?php } } }?>

<!-- Update Status Modal -->

<!-- Modal -->
<div id="updateStatus" class="modal fade updateStatusModal" role="dialog">
    <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update Status</h4>
        </div>
        <div class="modal-body" id="imagePreviewBody">
            <form name='updateStatus' class="updateStatusModalBody" method='POST' action=''>
                <h5 id="unit_pno_title">Unit - </h5>              
                <h5><?=$logAgent?></h5>          
                <div id="statusBodyContainer">
                </div>        
                
                <input type="hidden" name="pno" value="" >
                <input type="hidden" name="layout_id" value="" >
                <input type="hidden" name="rowID" value="" >
            </form>    
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>

    </div>
</div>
<!-- End Update Status Modal -->

<!--Property Log Modal -->
<div id="propertyLog" class="modal fade" role="dialog">
    <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Property Log</h4>
        </div>
        <div class="modal-body" id="imagePreviewBody">
            <h5> Property Log</h5>              
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Date</th>
                    <th scope="col">Remarks</th>
                    <th scope="col">User</th>
                    </tr>
                </thead>
                <tbody>
    
                </tbody>
            </table>              
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>

    </div>
</div>
<!--End Property Log Modal -->

<!-- ============================================================== -->
            <!-- End Modal Popup  -->
<!-- ============================================================== --> 


                
                </section>      
                </section>      
               
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            <script>

            // Create/Update Status Log
            $(document).on('click', '.updateStatusSubmit', function(e){
                e.preventDefault();
                let form = $(this).closest('.updateStatusModalBody');
                let modal = $(this).closest('.modal');
                let pno = form.find("input[name=pno]").val();
                let layout_id = form.find("input[name=layout_id]").val();
                let row_id = form.find("input[name=rowID]").val();
                let project_id = $('#project_id').val();
                let remarks = $(this).val();
                let log_remarks = '';
                if(remarks=='Booking') {
                    log_remarks = $("#log_remarks").val();
                }
                let task = 'updateStatus';

                $.ajax({
                    type: 'post',
                    url: 'include/ajax.php', 
                    data: {'pno':pno, 'task':task, 'remarks':remarks, 'layout_id':layout_id, 'project_id':project_id, 'log_remarks':log_remarks},
                    dataType: 'json',
                    beforeSend: function() {
                        $('.loader').show();
                    },
                    complete: function() {
                        $('.loader').hide();
                    },
                    success: function (response) {
                        if(response.success) {
                            $('.status-'+row_id).text(response.status);
                            $('.date-'+row_id).text(response.date);
                            $('.agent-'+row_id).text(response.agent);
                        }
                    modal.modal('toggle');    
                    }
                });
            });

            // Open Status Modal
            $(document).on('click', '.updateStatus', function(e){
                e.preventDefault();
                let pno = $(this).attr('data-pno');
                let layout_id = $(this).attr('data-id');
                let rowID = $(this).attr('data-rowId');
                let task = 'getStatusData';
                $.ajax({
                    type: 'post',
                    url: 'include/ajax.php', 
                    data: {'pno':pno, 'task':task, 'layout_id':layout_id},
                    dataType: 'json',
                    beforeSend: function() {
                        $('.loader').show();
                    },
                    complete: function() {
                        $('.loader').hide();
                    },
                    success: function (response) {
                        modalId = '#updateStatus';
                        $(modalId).find('#unit_pno_title').text('Unit - '+pno);
                        $(modalId).find('input[name=pno]').val(pno);
                        $(modalId).find('input[name=layout_id]').val(layout_id);
                        $(modalId).find('input[name=rowID]').val(rowID);
                        $(modalId).find('#statusBodyContainer').html(response.modalBody);
                    }
                });
            });

            // Open unit log modal
            $(document).on('click', '.propertyLog', function(e){
                e.preventDefault();
                let modalId = $(this).attr('modal-id');
                let pno = $(this).attr('data-pno');
                let layout_id = $(this).attr('data-id');
                let project_id = $('#project_id').val();
                let task = 'getUnitLog';
                $.ajax({
                    type: 'post',
                    url: 'include/ajax.php', 
                    data: {'pno':pno, 'task':task, 'layout_id':layout_id, 'project_id':project_id},
                    dataType: 'json',
                    beforeSend: function() {
                        $('.loader').show();
                    },
                    complete: function() {
                        $('.loader').hide();
                    },
                    success: function (response) {
                        modalId = '#propertyLog';
                        $(modalId).find('h5').text(pno+' - Property Log');
                        $(modalId).find('tbody').html(response.html);
                    }
                });
            });

            </script>

<!--Image Right Script for popup image-->
<script>
    function openModal() {
      $("#imgModal").show();
    }
    
    function closeModal() {
      $("#imgModal").hide();
    }
    
    var slideIndex = 1;
    showSlides(slideIndex);
    
    function plusSlides(n) {
      showSlides(slideIndex += n);
    }
    
    function currentSlide(n) {
      showSlides(slideIndex = n);
    }
    
    function showSlides(n) {
      var i;
      var slides = $(".mySlides");
      var captionText = document.getElementById("caption");
      if (n > slides.length) {slideIndex = 1}
      if (n < 1) {slideIndex = slides.length}
      for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";
      }
      slides[slideIndex-1].style.display = "block";
    }
</script>