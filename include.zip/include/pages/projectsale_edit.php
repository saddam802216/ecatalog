<style>
.general_info_cover_photo {
    width:150px; 
    height:124px; 
    padding:20px
}
.generalInfo_coverID {
    border: solid 5px #4ecdc4;
    background-color: #808080;
}
.required-element {
    color: red;
}
</style>

<?php
$layout = false;
$layout = $_GET['layout'];

$id = null;
if(isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
}
 
$data = Fetch::getProjectSaleByID($id); 


?>
<style>
.loader {
    position: fixed;
    z-index: 999;
    /* height: 2em;
    width: 2em; */
    overflow: show;
    margin: auto;
    top: 0%;
    left: 0%;
    bottom: 0;
    right: 0;
    background-color: #00000055;
    display: none;
}
.loader img {
    position: relative;
    top: 50%;
    left: 50%;
}
.hide-me {
    display: none;
}
.show-me{
    display: block;
}
.custum-tab-li {
    float: left;
    margin-bottom: -1px;
    position: relative;
    display: block;
    list-style: none;
    width: 100%;
    background-color: #e0e1e7;
    margin-bottom: 15px;
}
.custum-tab-li-a{
    margin-right: 2px;
    line-height: 1.42857143;
    border: 1px solid transparent;
    /* border-radius: 4px 4px 0 0; */
    position: relative;
    display: block;
    padding: 10px 15px 10px 0px;
    color: #2f2f2f;
    text-decoration: none;
    outline: none;
}

.custum-tab-li-a-span{
    padding: 11px 15px 12px;
    background-color: #fff;
    /* border-radius: 4px; */
}
.removeImage {
    color: red;
    position: relative;
    float: right;
}
.cover-photo {
    border: solid 3px red !important;
}
.image-main{
    background-color: #000;
    margin-left: 15px;
    margin-right: 15px;
    margin-top: 10px;
    border-top-right-radius: 4px;
    border-top-left-radius: 4px;
    padding-right: 0px;
    padding-left: 0px;
    border: solid 3px #fff;
}

@media only screen and (max-width: 768px) {
    .image-main{
        background-color: #000;
        margin-left: 0px;
        margin-right: 0px;
        margin-top: 10px;
        border-top-right-radius: 4px;
        border-top-left-radius: 4px;
        padding-right: 0px;
        padding-left: 0px;
        border: solid 3px #fff;
    }

    #generalInfo {
        margin: 15px 0px !important;
    }
}
</style>
<!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            
            
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="loader">
                    <img src="<?=BASE_URL.SITE_IMAGE_PATH.'loader-color.gif'?>" >
                </div>
                <section id="main-content">
                <section class="wrapper">
                <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Project Sale</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb" style="margin-bottom:0;">
                                    <li class="breadcrumb-item"><a href="<?=BASE_URL.'index.php'?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="<?=BASE_URL.'index.php?page=projectsale_edit'?>">Project Sale</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
                <div class="row" >
                    <div class="col-md-6">
                        
                        <li class="nav-item active custum-tab-li"> <a class="nav-link active custum-tab-li-a" data-toggle="tab" href="#generalInfo" role="tab"><span class="hidden-sm-up"></span> <span class="hidden-xs-down custum-tab-li-a-span">General Info</span></a> </li>

                        <div class="tab-pane active " id="generalInfo" role="tabpanel" style="background-color:#fff; padding:15px;">
                            <div class="p-20 w-85">    
                                <form class="form-horizontal style-form" name="project_sale_form" method="POST" id="projectSaleInfoForm" action="include/store.php" enctype="multipart/form-data">
                                <div class="form-group row">
                                    <label for="listing_type" class="col-sm-3 text-right control-label col-form-label">Listing Type</label>
                                    <div class="col-sm-7">
                                        <input type="text" name="listing_type" class="form-control" id="listing_type" value="Project Sale" disabled>
                                    </div>
                                </div> 

                                <div class="form-group">
                                    <label for="propertyid" class="col-sm-3 text-right control-label col-form-label">Property ID</label>
                                    <div class="col-sm-7">
                                        <input type="text" name="propertyid" class="form-control" id="propertyid" value="-Auto Running Number-" disabled>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="project_title" class="col-sm-3 text-right control-label col-form-label">Project Title<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                        <select class="select2 form-control custom-select" name="project_title" id="project_title" required>
                                        <option value="">Select Project Title </option>
                                        <?php
                                        $options = Helper::getTableData('projects');
                                        foreach($options as $key=>$option) {
                                            $selected = ($option->project_id==$data->project_title)?' selected':'';
                                            echo '<option value="'.$option->project_id.'" '.$selected.'>'.$option->project_title.'</option>';
                                        }
                                        
                                        ?>
                                        </select>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="layout" class="col-sm-3 text-right control-label col-form-label">Layout<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="layout" id="layout" required>

                                    <?php
                                    $options = unserialize(LAYOUT);
                                    foreach($options as $key=>$option) {
                                        $selected = ($key==$data->layout)?' selected':'';
                                        echo '<option value="'.$key.'"'.$selected.'>'.$option.'</option>';
                                    }

                                    ?>
                                    </select>
                                        
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="road_name" class="col-sm-3 text-right control-label col-form-label">Road Name<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="road_name" id="road_name" required>
                                    <option value="">Select Road Name </option>
                                    <?php
                                    $options = Helper::getTableData('project_road_name');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->project_road_id==$data->road_name)?' selected':'';
                                        echo '<option value="'.$option->project_road_id.'"'.$selected.'>'.$option->road_name.'</option>';
                                    }

                                    ?>
                                    </select>
                                        
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="state" class="col-sm-3 text-right control-label col-form-label">State<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="state" id="state" required>

                                    <option value="">Select State </option>
                                    <?php
                                    $options = Helper::getTableData('state');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->state_id==$data->state)?' selected':'';
                                        echo '<option value="'.$option->state_id.'"'.$selected.'>'.$option->state_title.'</option>';
                                    }
                                    ?>
                                    </select>
                                        
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="city" class="col-sm-3 text-right control-label col-form-label">City<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="city" id="city" required>

                                    <option value="">Select City </option>
                                    <?php
                                    $options = Helper::getTableData('city');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->city_id==$data->city)?' selected':'';
                                        echo '<option value="'.$option->city_id.'"'.$selected.'>'.$option->city_title.'</option>';
                                    }

                                    ?>
                                    </select>
                                    
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="tenure" class="col-sm-3 text-right control-label col-form-label">Tenure<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="tenure" id="tenure" required>

                                    <option value="">Select Tenure </option>
                                    <?php
                                    $options = Helper::getTableData('tenures');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->tenure_id==$data->tenure)?' selected':'';
                                        echo '<option value="'.$option->tenure_id.'"'.$selected.'>'.$option->tenure_title.'</option>';
                                    }

                                    ?>
                                    </select>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="reserve" class="col-sm-3 text-right control-label col-form-label">Reserve<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="reserve" id="reserve" required>

                                    <option value="">Select Reserve </option>
                                    <?php
                                    $options = Helper::getTableData('reserve');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->reserve_id==$data->reserve)?' selected':'';
                                        echo '<option value="'.$option->reserve_id.'"'.$selected.'>'.$option->reserve_title.'</option>';
                                    }
                                    ?>
                                    </select>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="commission" class="col-sm-3 text-right control-label col-form-label">Commission<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="commission" id="commission" required>

                                    <option value="">Select Commission </option>
                                    <?php
                                    $options = Helper::getTableData('commission');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->commission_id==$data->commission)?' selected':'';
                                        echo '<option value="'.$option->commission_id.'"'.$selected.'>'.$option->commission_title.'</option>';
                                    }

                                    ?>
                                    </select>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="poster_banner" class="col-sm-3 text-right control-label col-form-label">Poster/Banner<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="poster_banner" id="poster_banner" required>

                                    <?php
                                    $options = unserialize(POSTER_BANNER);
                                    foreach($options as $key=>$option) {
                                        $selected = ($key==$data->poster_banner)?' selected':'';
                                        echo '<option value="'.$key.'" '.$selected.'>'.$option.'</option>';
                                    }

                                    ?>
                                    </select>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="ads_date" class="col-sm-3 text-right control-label col-form-label">Advertisement Date<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                        <input type="date" name="ads_date" value="<?=$data->ads_date?>" class="form-control" id="ads_date" placeholder="First Name Here" required>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="remarks" class="col-sm-3 text-right control-label col-form-label">Remarks<span class="required-element"></span></label>
                                    <div class="col-sm-7">
                                        <textarea name="remarks" class="form-control" id="remarks"><?=$data->remarks?></textarea>
                                        <script>
                                                CKEDITOR.replace( 'remarks' );
                                        </script>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="listing_date" class="col-sm-3 text-right control-label col-form-label">Listing Date<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                        <input type="date" name="listing_date" class="form-control" id="listing_date" placeholder="First Name Here" value="<?=$data->listing_date?>" required>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="listing_by" class="col-sm-3 text-right control-label col-form-label">Listing By<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="listing_by" id="listing_by" required>

                                    <option value="">Select Listing By </option>
                                    <?php
                                    $options = Helper::getTableData('administrators');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->admin_id==$data->listing_by)?' selected':'';
                                        echo '<option value="'.$option->admin_id.'"'.$selected.'>'.$option->admin_firstname.'</option>';
                                    }

                                    ?>
                                    </select>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="bringin_by" class="col-sm-3 text-right control-label col-form-label">Bring In By<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                    <select class="select2 form-control custom-select" name="bringin_by" id="bringin_by" required>

                                    <option value="">Select Bring In By </option>
                                    <?php
                                    $options = Helper::getTableData('administrators');
                                    foreach($options as $key=>$option) {
                                        $selected = ($option->admin_id==$data->listing_by)?' selected':'';
                                        echo '<option value="'.$option->admin_id.'" '.$selected.'>'.$option->admin_firstname.'</option>';
                                    }
                                    
                                    ?>
                                    </select>
                                    </div>
                                    
                                </div> 

                                <div class="form-group row">
                                    <label for="photo_upload" class="col-sm-3 text-right control-label col-form-label">Photo Upload<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                        <input type="file" name="photo_upload[]" class="form-control" id="photo_upload" multiple>
                                    </div>
                                </div> 

                                <div class="form-group row">
                                    <label for="sale_youtube_video" class="col-sm-3 text-right control-label col-form-label">YouTube Video<span class="required-element">*</span></label>
                                    <div class="col-sm-7">
                                        <input type="text" name="sale_youtube_video" class="form-control" id="sale_youtube_video" value="<?=$data->projectSaleYouTube->file_name?>">
                                    </div>
                                </div> 
                                
                                <div class="form-group row image-row">
                                    <?php  
                                    $coverPhoto = '';
                                    if(isset($data->projectSaleImage)){ 
                                    foreach($data->projectSaleImage as $k=>$img) {
                                        $coverPhotoClass = '';
                                        $coverPhoto_tooltip = '';
                                        if($img->file_cover) {
                                            $coverPhoto = 1;
                                            $coverPhotoClass = 'cover-photo';
                                            $coverPhoto_tooltip = 'data-toggle="tooltip" title="Cover Photo!"';
                                        }
                                    ?>
                                    <div class="col-sm-3 col-xs-6 image-main <?=$coverPhotoClass?>" style="margin-top: 10px;" <?=$coverPhoto_tooltip?>>
                                        <a href="javascript::void()" class="removeImage" data-id="<?=$img->file_id?>" data-type="sale" ><i class="fa fa-times fa-1x "></i></a>
                                        <img src="<?=BASE_URL.UPLOAD_IMAGE_PATH.$img->file_name?>" alt="Los Angeles" style="width:100%; height:60px" class="img-main">
                                    </div>
                                    <?php } } ?>
                                </div>
                                <div id="GIcoverPhotoLabel">
                                </div>            
                                <div class="row" style="padding-bottom:20px">
                                    <div class="col-sm-3"></div>
                                    <div class="card-body col-sm-7" >
                                        <input type="submit" name="projectSaleInfoSubmit" class="btn btn-primary" id="projectSaleInfoSubmit" value="Submit" style="width:100%"/>
                                    </div>
                                </div>
                                <input type="hidden" name="property_id" value="<?=$data->property_id?>">
                                <input type="hidden" name="sale_cover_photo" id="sale_cover_photo" value="<?=$coverPhoto?>">
                                </form>
                            </div> 
                        </div>
                    </div>

                            
                        <div class="col-sm-6"> 
                        <?php if($layout=true) { ?>                    
                            <div class="card">
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs" role="tablist">
                                    

                                    <?PHP
                                    // prx($data);
                                        for($i=0; $i<$data->layout; $i++) {
                                            $UIcount = $i+1;
                                            $active = ($i==0)?' active':'';
                                    ?>
                                    <li class="nav-item <?=$active?>"> <a class="nav-link <?=$active?>" data-toggle="tab" href="#unitInfo<?=$UIcount?>" role="tab"><span class="hidden-sm-up"></span> <span class="hidden-xs-down">Layout <?=$UIcount?> (Unit Info)</span></a> </li>
                                    <?PHP
                                        }
                                    ?>
                                    
                                </ul>
                                <!-- Tab panes -->
                                
                                <div class="tab-content form-panel" style="padding:0px; box-shadow:none; margin:15px;">       
                                
                                    <?PHP
                                    
                                        $unitInfo = $data->unitInfo;
                                        for($i=0; $i<$data->layout; $i++) {
                                            $UIcount = $i+1;
                                            $active = ($i==0)?' active':'';
                                    ?>
                                    <div class="tab-pane unitInfoTabBody p-20 <?=$active?>" id="unitInfo<?=$UIcount?>" role="tabpanel">
                                        <div class="p-20 w-85 border unitInfoFormBody"> 
                                            
                                        <form class="form-horizontal style-form" name="unit_info_form" method="POST" id="projectSaleUnitInfoForm" action="include/store.php" enctype="multipart/form-data">

                                            <div class="form-group row">
                                                <label for="pno" class="col-sm-3 text-right control-label col-form-label">PNo</label>
                                                <div class="col-sm-7">
                                                    <input type="text" name="pno" class="form-control pno" id="pno" placeholder="Enter PNo" value="<?php echo isset($unitInfo[$i]->pno)?$unitInfo[$i]->pno:''; ?>">
                                                </div>
                                            </div> 

                                            <div class="form-group row">
                                                <label for="facing" class="col-sm-3 text-right control-label col-form-label">Facing</label>
                                                <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select facing" name="facing" id="facing"><option value="">Select Facing </option>

                                                    <?php
                                                    
                                                    $options = Helper::getTableData('facing');
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($option->facing_id==$unitInfo[$i]->facing)?' selected':'';
                                                    ?>

                                                    <option value="<?=$option->facing_id?>" <?=$selected?>> <?=$option->facing_title?></option>
                                
                                                    <?php    
                                                        }
                                                    ?>
                                                    </select>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label for="land_area" class="col-sm-3 text-right control-label col-form-label">Land Area Sqft</label>
                                                    <div class="col-sm-7">
                                                        <input type="number" name="land_area" class="form-control land_area" id="land_area" placeholder="Enter Land Area in Sqft" value="<?=$unitInfo[$i]->land_area?>">
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label for="built_up" class="col-sm-3 text-right control-label col-form-label">Built Up Sqft</label>
                                                    <div class="col-sm-7">
                                                        <input type="number" name="built_up" class="form-control built_up" id="built_up" placeholder="Enter Built Up in Sqft" value="<?=$unitInfo[$i]->built_up?>">
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label for="category" class="col-sm-3 text-right control-label col-form-label">Category</label>
                                                    <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select category" name="category" id="category"><option value="">Select Category </option>
                                                    <?php
                                                    
                                                    $options = Helper::getTableData('category');
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($option->category_id==$unitInfo[$i]->category)?' selected':'';
                                                    ?>

                                                    <option value="<?=$option->category_id?>" <?=$selected?>> <?=$option->category_title?></option>
                                
                                                    <?php    
                                                        }
                                                    ?>
                                                    </select>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label for="type" class="col-sm-3 text-right control-label col-form-label">Type</label>
                                                    <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select type" name="type" id="type"><option value="">Select Type </option>
                                                    <?php
                                                    
                                                    $options = Helper::getTableData('types');
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($option->type_id==$unitInfo[$i]->type)?' selected':'';
                                                    ?>

                                                    <option value="<?=$option->type_id?>" <?=$selected?>> <?=$option->type_title?></option>
                                
                                                    <?php    
                                                        }
                                                    ?>
                                                    </select>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="concept" class="col-sm-3 text-right control-label col-form-label">Concept</label>
                                                    <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select concept" name="concept" id="concept"><option value="">Select Concept </option>
                                                    <?php
                                                    
                                                    $options = Helper::getTableData('concepts');
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($option->concept_id==$unitInfo[$i]->concept)?' selected':'';
                                                    ?>

                                                    <option value="<?=$option->concept_id?>" <?=$selected?>> <?=$option->concept_title?></option>
                                
                                                    <?php    
                                                        }
                                                    ?>
                                                    </select>

                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="room" class="col-sm-3 text-right control-label col-form-label">Room</label>
                                                    <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select room" name="room" id="room">

                                                    <?php
                                                    
                                                    $options = unserialize(ROOM);
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($key==$unitInfo[$i]->room)?' selected':'';
                                                    ?>

                                                    <option value="<?=$key?>" <?=$selected?>> <?=$option?></option>
                                
                                                    <?php    
                                                        }
                                                    ?>
                                                    </select>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="bathroom" class="col-sm-3 text-right control-label col-form-label">Bathroom</label>
                                                    <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select bathroom" name="bathroom" id="bathroom">
                                                    <?php
                                                    
                                                    $options = unserialize(BATHROOM);
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($key==$unitInfo[$i]->bathroom)?' selected':'';
                                                    ?>

                                                    <option value="<?=$key?>" <?=$selected?>> <?=$option?></option>
                                
                                                    <?php    
                                                        }
                                                    ?>
                                                    </select>    
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="flooring" class="col-sm-3 text-right control-label col-form-label">Flooring</label>
                                                    <div class="col-sm-7">
                                                    <select class="select2 form-control custom-select flooring" name="flooring" id="flooring">
                                                    <option value="">Select Flooring </option>
                                                    <?php
                                                    
                                                    $options = Helper::getTableData('flooring');
                                                    foreach($options as $key=>$option) {
                                                        $selected = ($option->flooring_id==$unitInfo[$i]->flooring)?' selected':'';
                                                    ?>

                                                    <option value="<?=$option->flooring_id?>" <?=$selected?>> <?=$option->flooring_title?></option>
                                
                                                    <?php    
                                                        }
                                                    ?> 
                                                    </select>    
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="s&p_price" class="col-sm-3 text-right control-label col-form-label">S&P Price</label>
                                                    <div class="col-sm-7">
                                                        <input type="number" name="s&p_price" class="form-control snp_price" id="s&p_price" placeholder="Enter S&P Price" value="<?=$unitInfo[$i]->snp_price?>">
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="promotion_price" class="col-sm-3 text-right control-label col-form-label">Promotion Price</label>
                                                    <div class="col-sm-7">
                                                        <input type="number" name="promotion_price" class="form-control promotion_price" id="promotion_price" placeholder="Enter Promotion Price" value="<?=$unitInfo[$i]->promotion_price?>">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="photo_upload" class="col-sm-3 text-right control-label col-form-label">Photo Upload</label>
                                                    <div class="col-sm-7">
                                                        <input type="file" name="unitinfo_photo_upload[]" class="form-control unitinfo_photo_upload" multiple>
                                                    </div>
                                                </div> 

                                                <div class="form-group row">
                                                    <label for="unit_youtube_video" class="col-sm-3 text-right control-label col-form-label">YouTube Video<span class="required-element">*</span></label>
                                                    <div class="col-sm-7">
                                                        <input type="text" name="unit_youtube_video" class="form-control" id="unit_youtube_video" value="<?php echo isset($unitInfo[$i]->projectSaleUnitYouTube->file_name)?$unitInfo[$i]->projectSaleUnitYouTube->file_name:''; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group row image-row">
                                                <?php  
                                                $coverPhoto = '';
                                                if(isset($unitInfo[$i]->unitInfoImages)){
                                                foreach($unitInfo[$i]->unitInfoImages as $k=>$img) {
                                                    $coverPhotoClass = '';
                                                    $coverPhoto_tooltip = '';
                                                    if($img->file_cover) {
                                                        $coverPhoto = 1;
                                                        $coverPhotoClass = 'cover-photo';
                                                        $coverPhoto_tooltip = 'data-toggle="tooltip" title="Cover Photo!"';
                                                    }
                                                
                                                ?>
                                                <div class="col-sm-3 col-xs-6 image-main <?=$coverPhotoClass?>" style="margin-top: 10px;" <?=$coverPhoto_tooltip?>>
                                                <a href="javascript::void()" class="removeImage" data-id="<?=$img->file_id?>" data-type="unit"><i class="fa fa-times fa-1x"></i></a>
                                                    <img src="<?=BASE_URL.UPLOAD_UNITINFO_IMAGE_PATH.$img->file_name?>" alt="Los Angeles" style="width:100%; height:60px" class="img-main">
                                                </div>
                                                <?php } }?>
                                                </div>

                                                <div class="UIcoverPhotoLabel">
                                                </div>   
                                                <input type="hidden" class="layout_number" value="<?=$UIcount?>">         
                                                <div class="row" style="padding-bottom:20px">
                                                    <div class="col-sm-3"></div>
                                                    <div class="card-body col-sm-7" >
                                                        <input type="submit" name="projectSaleUnitInfoSubmit" class="btn btn-primary" id="projectSaleUnitInfoSubmit" value="Submit" style="width:100%"/>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="unitInfo_id" value="<?php echo isset($unitInfo[$i]->unit_id)?$unitInfo[$i]->unit_id:''; ?>">

                                                <input type="hidden" name="property_id" value="<?=$data->property_id?>">

                                                <input type="hidden" name="unit_cover_photo" value="<?=$coverPhoto?>" class="unit_cover_photo">

                                                </form>     
                                            </div>
                                        </div>

                                    <?PHP 
                                        }
                                    ?>
                                    
                                </div>
                                
                            </div>  
                            <?php } ?>     <!-- End of Layout  -->         
                    </div>
                </div>  
                </section>      
                </section>      
               
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
                
                <!-- Modal -->
                <div id="imagePreviewModal" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
                  <div class="modal-dialog">
                
                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close closeModal" >&times;</button>
                        <h4 class="modal-title">Select Cover Photo</h4>
                      </div>
                      <div class="modal-body" id="imagePreviewBody">
                        
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default closeModal" >Close</button>
                      </div>
                    </div>
                
                  </div>
                </div>
                
                <script>
                    $(document).ready(function(){
                        $(document).on('change', '#layout', function(){
                            let count = $(this).val();
                            $('div.unitInfoFormBody').hide();        
                            $('div.unitInfoFormBody:lt('+count+')').show();
                            let newCount = count-1;
                            $('div.card li.navItemTab').hide();        
                            $('div.card li.navItemTab:lt('+newCount+')').show();
                        });
                    });
                    
                    // open modal
                    
                    $('#photo_upload').on('change', function() {
                        // let isCoverPhoto = $(this).closest('form').find('[name="sale_cover_photo"]').val();
                        let isCoverPhoto = $(this).closest('form').find('.cover-photo').length;
                        if(isCoverPhoto>0){
                            return false;
                        }
                        $('#imagePreviewBody').empty();
                        $('#imagePreviewModal').modal('toggle');
                        imagesPreview(this, '#imagePreviewBody',0 , isCoverPhoto);
                    });
                    
                var imagesPreview = function(input, placeToInsertImagePreview, layoutNo=0, coverPhoto=false) {
                    if (input.files) {
                        var filesAmount = input.files.length;
                        
                        for (i = 0; i < filesAmount; i++) {
                            var reader = new FileReader();
                        
                            let fileName = input.files[i].name;
                            reader.onload = function(event) {
                                $($.parseHTML('<img class="general_info_cover_photo" data-name ="'+fileName+'" data-layout="'+layoutNo+'" src="'+event.target.result+'">')).appendTo(placeToInsertImagePreview);
                            }
            
                            reader.readAsDataURL(input.files[i]);
                        }
                        // placeToInsertImagePreview.append('<input type="hidden" name="cover_photo" id="cover_photo" value="'+coverPhoto+'">');

                        $($.parseHTML('<input type="hidden" name="cover_photo" id="cover_photo" value="'+coverPhoto+'">')).appendTo(placeToInsertImagePreview);

                    }
            
                };
                // Add cover image name in hidden field
                $(document).on('click', '.general_info_cover_photo', function(){
                    let layoutNo = $(this).attr('data-layout');
                    if($(this).hasClass('generalInfo_coverID')) {
                        $(this).removeClass('generalInfo_coverID');
                        if(layoutNo==0) {
                            $('#GIcoverPhotoLabel').empty();
                        }else{
                            $('#unitInfo'+layoutNo).find('.UIcoverPhotoLabel').empty();
                        }
                        return false;
                    }    
                    let photoName = $(this).attr('data-name');
                    let checkedCount = $('.generalInfo_coverID').length;
                    
                    if(checkedCount>0) {
                        alert("You can select one image as cover photo");
                        return false;
                    }
                    if(layoutNo==0) {
                        $('#GIcoverPhotoLabel').empty();
                    }else{
                        $('#unitInfo'+layoutNo).find('.UIcoverPhotoLabel').empty();
                    }
                    
                    let isChecked = $(this).hasClass('generalInfo_coverID');
                    if(!isChecked) {
                        $(this).addClass('generalInfo_coverID');
                        let coverHtml = '<input type="hidden" name="general_info_cover_photo" value="'+photoName+'">';
                        if(layoutNo==0) {
                            $('#GIcoverPhotoLabel').append(coverHtml);
                        }else{
                            let index = layoutNo-1;
                            let coverHtml = '<input type="hidden" name="unit_info_cover_photo" value="'+photoName+'">';
                            $('#unitInfo'+layoutNo).find('.UIcoverPhotoLabel').append(coverHtml);
                        }
                        
                    }else{
                        $(this).removeClass('generalInfo_coverID');
                        if(layoutNo==0) {
                            $('#GIcoverPhotoLabel').empty();
                        }else{
                            $('#unitinfo'+layoutNo).find('.UIcoverPhotoLabel').empty();
                        }
                    }
                    
                });


                //Photo upload for Unit info modal

                    $('.unitinfo_photo_upload').on('change', function() {
                        // let isCoverPhoto = $(this).closest('form').find('[name="unit_cover_photo"]').val();
                        let isCoverPhoto = $(this).closest('form').find('.cover-photo').length;
                        if(isCoverPhoto>0){
                            return false;
                        }
                        $('#imagePreviewBody').empty();
                        $('#imagePreviewModal').modal('toggle');
                        let layoutNo = $(this).closest('.unitInfoFormBody').find('.layout_number').val();
                        imagesPreview(this, '#imagePreviewBody', layoutNo, isCoverPhoto);
                    }); 

                // Check Cover Photo and display message

                $(document).on('click', '.closeModal', function(){
                    let thisModal = $(this).closest('#imagePreviewModal');
                    let isCP = thisModal.find('[name="cover_photo"]').val();
                    isCP = parseInt(isCP);
                    if(isCP) {
                        if(thisModal.find('img').hasClass('generalInfo_coverID')) {
                            if(confirm("Do you want to delete last cover photo")){
                                $('#imagePreviewModal').modal('toggle');
                            }
                        }else{
                            $('#imagePreviewModal').modal('toggle');
                        }
                    }else{
                        if( !(thisModal.find('img').hasClass('generalInfo_coverID')) ) {
                            alert("Please select cover photo");
                            return false;
                        }else{
                            $('#imagePreviewModal').modal('toggle');
                        }
                    }
                });    
                    
                // Submit Form
                // $('#submit_project').on('click', function(){
                    
                //     $('form#form_project').submit();

                // });

                // Auto Update Facing value

                // $(document).on('change', '.facing:first', function(){
                //     let value = $(this).val();
                //     $('.facing').val(value);
                // });

                // $(document).on('change', '.land_area:first', function(){
                //     let value = $(this).val();
                //     $('.land_area').val(value);
                // });

                // $(document).on('change', '.built_up:first', function(){
                //     let value = $(this).val();
                //     $('.built_up').val(value);
                // });

                // $(document).on('change', '.category:first', function(){
                //     let value = $(this).val();
                //     $('.category').val(value);
                // });
                
                // $(document).on('change', '.type:first', function(){
                //     let value = $(this).val();
                //     $('.type').val(value);
                // });
                
                // $(document).on('change', '.concept:first', function(){
                //     let value = $(this).val();
                //     $('.concept').val(value);
                // });
                
                // $(document).on('change', '.room:first', function(){
                //     let value = $(this).val();
                //     $('.room').val(value);
                // });
                
                // $(document).on('change', '.bathroom:first', function(){
                //     let value = $(this).val();
                //     $('.bathroom').val(value);
                // });
                
                // $(document).on('change', '.flooring:first', function(){
                //     let value = $(this).val();
                //     $('.flooring').val(value);
                // });
                
                // $(document).on('change', '.snp_price:first', function(){
                //     let value = $(this).val();
                //     $('.snp_price').val(value);
                // });

                // $(document).on('change', '.promotion_price:first', function(){
                //     let value = $(this).val();
                //     $('.promotion_price').val(value);
                // });
                
                
                // Update Project Sale Info and Image AJAX

                $(document).on('click', '#projectSaleInfoSubmit', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    var form = $('#projectSaleInfoForm');
                    let coverImg = form.find('.cover-photo').length;
                    let coverImgUploade = form.find('input[name=general_info_cover_photo]').length;
                    if(coverImg==0 && coverImgUploade==0) {
                        alert('Please select cover photo');
                        return false;
                    }
                    let saleFormData = form.serialize();

                    // FILE 
                    var form_data = new FormData();
                    // Read selected files
                    var files = $('#photo_upload')[0];
                    for (var index = 0; index < files.files.length; index++) {
                        form_data.append("files[]", files.files[index]);
                    }
                    form_data.append("saleFormData", saleFormData);
                    form_data.append("task", 'updateSaleInfo');
                    
                    
                    // AJAX request
                    $.ajax({
                        type: 'post',
                        url: 'include/ajax.php', 
                        data: form_data,
                        dataType: 'json',
                        contentType: false,
                        processData: false,
                        // cache : false,
                        beforeSend: function() {
                            $('.loader').show();
                        },

                        complete: function() {
                            $('.loader').hide();
                        },
                        success: function (response) {
                            if(response.success) {
                                window.location.replace(response.url);
                            }else {
                                alert(response.message);
                            }
                        //    $('.nav-item:first').hide();
                        //    $('.tab-pane:first').hide();
                        //    $('.hide-me').removeClass('hide-me'); 
                            // alert(response.message);
                        }
                    });
                });


                // Update Unit Info and Image AJAX

                $(document).on('click', '#projectSaleUnitInfoSubmit', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    var form = $(this).closest('#projectSaleUnitInfoForm');
                    let coverImg = form.find('.cover-photo').length;
                    let coverImgUploade = form.find('input[name=unit_info_cover_photo]').length;
                    
                    if(coverImg==0 && coverImgUploade==0) {
                        alert('Please select cover photo');
                        return false;
                    }
                    let unitInfoFormData = form.serialize();
                    // console.log(unitInfoFormData);
                    // FILE 
                    var form_data = new FormData();
                    // Read selected files  
                    var files = form.find('.unitinfo_photo_upload')[0];
                    for (var index = 0; index < files.files.length; index++) {
                        form_data.append("files[]", files.files[index]);
                    }
                    form_data.append("unitInfoFormData", unitInfoFormData);
                    form_data.append("task", 'updateUnitInfo');
                    
                    // AJAX request
                    $.ajax({
                        type: 'post',
                        url: 'include/ajax.php', 
                        data: form_data,
                        dataType: 'json',
                        contentType: false,
                        processData: false,
                        // cache : false,
                        beforeSend: function() {
                            $('.loader').show();
                        },

                        complete: function() {
                            $('.loader').hide();
                        },
                        success: function (response) {
                            form.find('[name="unitInfo_id"]').val(response.unit_id);
                            if(response.imageHtml!='') {
                                form.find('.image-row').empty();
                                form.find('.image-row').append(response.imageHtml);
                            }
                            form.find('.unitinfo_photo_upload').val('');
                            // alert(response.message);
                        }
                    });
                });

                // remove Image AJAX

                $(document).on('click', '.removeImage', function(e){
                    e.preventDefault();
                    if(!confirm("Do you want to remove this image permanently!")) {
                        return false;
                    }
                    let onThis = $(this).closest('.image-main');
                    let id = $(this).attr('data-id');
                    let type = $(this).attr('data-type');

                    // AJAX request
                    $.ajax({
                        type: 'post',
                        url: 'include/ajax.php', 
                        data: {'task':'removeImage', 'id':id, 'type':type},
                        dataType: 'json',
                        // contentType: false,
                        // processData: false,
                        // cache : false,
                        beforeSend: function() {
                            $('.loader').show();
                        },

                        complete: function() {
                            $('.loader').hide();
                        },
                        success: function (response) {
                            if(response.success) {
                                onThis.remove();
                            }
                            // form.find('[name="unitInfo_id"]').val(response.unit_id);
                            // alert(response.message);
                        }
                    });
                });

                // Add image as cover photo

                $(document).on('click', '.img-main ', function(){
                    let form = $(this).closest('form');
                    let selected_photo = $(this);
                    let file_id = selected_photo.closest('.image-main').find('a').attr('data-id');
                    let type = selected_photo.closest('.image-main').find('a').attr('data-type');
                    if(type=='sale') {
                        var field_id = form.find('input[name=property_id]').val();
                    }else{
                        var field_id = form.find('input[name=unitInfo_id]').val();
                    }
                    
                    // AJAX request
                    $.ajax({
                        type: 'post',
                        url: 'include/ajax.php', 
                        data: {'task':'updateCoverPhoto', 'field_id':field_id, 'file_id':file_id, 'type':type},
                        dataType: 'json',
                        beforeSend: function() {
                            $('.loader').show();
                        },

                        complete: function() {
                            $('.loader').hide();
                        },
                        success: function (response) {
                            if(response.success) {
                                form.find('.cover-photo').removeClass('cover-photo');
                                selected_photo.closest('.image-main').addClass('cover-photo');
                            }else{
                                alert('Cover photo not updated, Plaese try again!');
                            }
                        }
                    });

                });

                </script>
